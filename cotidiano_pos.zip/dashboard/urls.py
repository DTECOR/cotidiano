from django.urls import path
from .views import obtener_dashboard

urlpatterns = [
    path('api/dashboard/', obtener_dashboard, name="obtener_dashboard"),
]
