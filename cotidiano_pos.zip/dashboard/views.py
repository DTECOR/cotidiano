from django.db.models import Count, Sum, F
from django.utils import timezone
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from pos.models import Orden, DetalleOrden, Ingrediente

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def obtener_dashboard(request):
    """Retorna métricas clave para el dashboard administrativo"""

    # 📌 Obtener estado de órdenes
    estados_ordenes = Orden.objects.values("estado").annotate(total=Count("id"))

    # 📌 Calcular total de ventas del día
    fecha_actual = timezone.now().date()
    ventas_hoy = DetalleOrden.objects.filter(
        orden__fecha_creacion__date=fecha_actual,
        orden__estado="COMPLETADA"
    ).aggregate(total_ventas=Sum(F("cantidad") * F("producto__precio")))  # ✅ Django maneja la multiplicación correctamente

    ventas_hoy_total = ventas_hoy["total_ventas"] or 0  # ✅ Evita valores nulos

    # 📌 Obtener los platos más vendidos (top 5)
    platos_mas_vendidos = list(
        DetalleOrden.objects.values("producto__nombre")
        .annotate(total_vendidos=Sum("cantidad"))
        .order_by("-total_vendidos")[:5]
    )

    # 📌 Estado del inventario (ingredientes con bajo stock)
    ingredientes_bajo_stock = list(
        Ingrediente.objects.filter(stock__lt=10)
        .values("nombre", "stock")
    )

    return Response({
        "ordenes": list(estados_ordenes),
        "ventas_hoy": ventas_hoy_total,
        "platos_mas_vendidos": platos_mas_vendidos,
        "ingredientes_bajo_stock": ingredientes_bajo_stock,
    })
