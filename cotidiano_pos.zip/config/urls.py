"""
Configuración de URLs para el proyecto config.
"""

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenRefreshView
from pos.views import (
    CustomTokenObtainPairView, obtener_usuario_actual,
    cambiar_estado_orden, OrdenViewSet, UsuarioViewSet,
    ProductoViewSet, IngredienteViewSet
)
from dashboard.views import obtener_dashboard  # ✅ Se importa correctamente la vista del dashboard

# 🔹 Registro de rutas de los ViewSets
router = DefaultRouter()
router.register(r'ordenes', OrdenViewSet, basename="orden")  # ✅ Rutas de Órdenes
router.register(r'usuarios', UsuarioViewSet, basename="usuario")  # ✅ Rutas de Usuarios
router.register(r'productos', ProductoViewSet, basename="producto")  # ✅ Rutas de Productos
router.register(r'ingredientes', IngredienteViewSet, basename="ingrediente")  # ✅ Rutas de Ingredientes

inventario_routes = []
try:
    from inventario.urls import urlpatterns as inventario_urls
    inventario_routes = [path('api/inventario/', include('inventario.urls'))]
except ModuleNotFoundError:
    print("⚠️ Advertencia: `inventario.urls` no existe, verifícalo en la carpeta `inventario/`.")

urlpatterns = [
    # Panel de administración
    path('admin/', admin.site.urls),

    # Rutas API REST
    path('api/', include(router.urls)),  # ✅ Registro de todos los ViewSets

    # Rutas de Inventario y POS
    path('api/pos/', include('pos.urls')),  # ✅ Se incluyen todas las rutas de 'pos'

    # Autenticación con JWT (Usando la vista personalizada)
    path('api/token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),  # ✅ Login corregido
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),  # ✅ Refresh token

    # Endpoint para obtener datos del usuario actual
    path('api/usuarios/me/', obtener_usuario_actual, name="usuario_actual"),

    # Gestión de Órdenes
    path('api/ordenes/<int:pk>/estado/', cambiar_estado_orden, name='cambiar_estado_orden'),  # ✅ Ruta correcta

    # Dashboard
    path('api/dashboard/', obtener_dashboard, name="dashboard_data"),  # ✅ Se asegura que la ruta exista correctamente
] + inventario_routes

# 🔹 Servir archivos estáticos y multimedia en desarrollo
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
