import os
import django  # ✅ Inicializar Django correctamente
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
import pos.routing  # ✅ Importar las rutas WebSocket

# ✅ Configuración del entorno de Django antes de iniciar ASGI
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

# ✅ Aplicación ASGI combinando HTTP y WebSockets
application = ProtocolTypeRouter({
    "http": get_asgi_application(),  # ✅ Soporta solicitudes HTTP normales
    "websocket": AuthMiddlewareStack(
        URLRouter(
            pos.routing.websocket_urlpatterns  # ✅ Manejo de WebSockets
        )
    ),
})
