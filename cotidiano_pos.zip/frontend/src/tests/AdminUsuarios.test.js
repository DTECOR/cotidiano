import { render, screen } from "@testing-library/react";
import AdminUsuarios from "../pages/AdminUsuarios";

test("renders user list", async () => {
  render(<AdminUsuarios />);
  const titleElement = await screen.findByText(/Gestión de Usuarios/i);
  expect(titleElement).toBeInTheDocument();
});
