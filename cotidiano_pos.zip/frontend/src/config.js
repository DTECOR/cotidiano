// ✅ Configuración Segura de Variables de Entorno
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://127.0.0.1:8000/api";

// ✅ Función para manejar las variables de entorno de manera segura
const getConfig = (key, defaultValue = null) => {
  try {
    const value = process.env[key];
    return value !== undefined ? value : defaultValue;
  } catch (error) {
    console.error(`Error obteniendo configuración: ${key}`, error);
    return defaultValue;
  }
};

// ✅ Exportar Configuración
export const CONFIG = {
  API_BASE_URL,
  USE_SECURE_STORAGE: getConfig("REACT_APP_USE_SECURE_STORAGE", "false") === "true", // Permitir almacenamiento seguro si está habilitado
};

export default CONFIG;
