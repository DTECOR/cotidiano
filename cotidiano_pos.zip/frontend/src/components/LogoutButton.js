import React, { useEffect, useState } from "react";
import { Button } from "@mui/material";
import { useNavigate } from "react-router-dom";
import api, { logout } from "../services/api";

const LogoutButton = () => {
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("access_token");
    setIsAuthenticated(!!token);
  }, []);

  const handleLogout = async () => {
    await logout();
    setIsAuthenticated(false);
    navigate("/login");
  };

  return (
    <>
      {isAuthenticated && (
        <Button onClick={handleLogout} variant="contained" color="secondary">
          Cerrar Sesión
        </Button>
      )}
    </>
  );
};

export default LogoutButton;
