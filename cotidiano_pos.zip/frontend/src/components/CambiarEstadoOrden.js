// src/components/CambiarEstadoOrden.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button, Select, MenuItem, FormControl, InputLabel, Grid } from '@mui/material';

const CambiarEstadoOrden = () => {
  const [ordenes, setOrdenes] = useState([]);
  const [estado, setEstado] = useState('');
  const [selectedOrden, setSelectedOrden] = useState('');

  useEffect(() => {
    // Cargar órdenes desde el backend
    axios.get('/api/ordenes/')
      .then(response => setOrdenes(response.data))
      .catch(err => console.error(err));
  }, []);

  const handleSubmit = () => {
    if (!selectedOrden || !estado) {
      alert('Por favor, selecciona una orden y un estado.');
      return;
    }

    // Enviar solicitud para actualizar el estado de la orden
    axios.patch(`/api/ordenes/${selectedOrden}/estado/`, { estado })
      .then(response => {
        alert('Estado actualizado con éxito');
        setEstado('');
        setSelectedOrden('');
      })
      .catch(err => {
        console.error(err);
        alert('Error al actualizar el estado de la orden.');
      });
  };

  return (
    <div>
      <h2>Cambiar Estado de Orden</h2>
      
      <Grid container spacing={2}>
        <Grid item xs={6}>
          <FormControl fullWidth>
            <InputLabel>Orden</InputLabel>
            <Select
              value={selectedOrden}
              onChange={(e) => setSelectedOrden(e.target.value)}
              label="Orden"
            >
              {ordenes.map((orden) => (
                <MenuItem key={orden.id} value={orden.id}>
                  {`Orden ${orden.id} - Estado: ${orden.estado}`}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>

        <Grid item xs={6}>
          <FormControl fullWidth>
            <InputLabel>Estado</InputLabel>
            <Select
              value={estado}
              onChange={(e) => setEstado(e.target.value)}
              label="Estado"
            >
              <MenuItem value="pendiente">Pendiente</MenuItem>
              <MenuItem value="en_proceso">En Proceso</MenuItem>
              <MenuItem value="terminada">Terminada</MenuItem>
              <MenuItem value="pagada">Pagada</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>
      
      <Button onClick={handleSubmit} variant="contained" color="primary">
        Actualizar Estado
      </Button>
    </div>
  );
};

export default CambiarEstadoOrden;
