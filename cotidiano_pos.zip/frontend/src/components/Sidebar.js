import React from "react";
import { Link } from "react-router-dom";
import { List, ListItem, ListItemText, Divider } from "@mui/material";

const Sidebar = () => {
  const userRole = localStorage.getItem("user_role"); // ✅ Obtener el rol del usuario

  return (
    <List component="nav">
      <ListItem button component={Link} to="/dashboard">
        <ListItemText primary="Dashboard" />
      </ListItem>

      <ListItem button component={Link} to="/ordenes">
        <ListItemText primary="Órdenes" />
      </ListItem>

      {/* ✅ Solo ADMIN puede ver la gestión de usuarios */}
      {userRole === "ADMIN" && (
        <ListItem button component={Link} to="/usuarios">
          <ListItemText primary="Usuarios" />
        </ListItem>
      )}

      {/* ✅ Solo COCINERO puede ver el menú cocinero */}
      {userRole === "COCINERO" && (
        <ListItem button component={Link} to="/menu">
          <ListItemText primary="Menú Cocinero" />
        </ListItem>
      )}

      {/* ✅ Solo CAJERO puede ver facturación */}
      {userRole === "CAJERO" && (
        <ListItem button component={Link} to="/facturacion">
          <ListItemText primary="Facturación" />
        </ListItem>
      )}

      <Divider />

      {/* ✅ Solo ADMIN puede ver el inventario */}
      {userRole === "ADMIN" && (
        <ListItem button component={Link} to="/inventario">
          <ListItemText primary="Inventario" />
        </ListItem>
      )}
    </List>
  );
};

export default Sidebar;
