import React, { useState, useEffect } from "react";
import { login } from "../services/api";
import { useNavigate } from "react-router-dom";
import { Button, TextField, Container, Typography, Alert } from "@mui/material";

const LoginForm = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    try {
      if (typeof window !== "undefined" && window.localStorage) {
        const token = localStorage.getItem("access_token");
        const userRole = localStorage.getItem("user_role");

        if (token && userRole) {
          console.log("🔹 Usuario ya autenticado. Redirigiendo...");
          navigate("/dashboard", { replace: true });
        } else {
          setIsCheckingAuth(false);
        }
      } else {
        console.warn("⚠️ localStorage no está disponible.");
        setIsCheckingAuth(false);
      }
    } catch (error) {
      console.error("🔴 Error accediendo al almacenamiento:", error);
      setIsCheckingAuth(false);
    }
  }, []);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError(null);

    try {
      console.log("📡 Iniciando sesión...");
      const response = await login(email, password);

      if (!response || !response.access) {
        setError("⚠️ Usuario o contraseña incorrectos.");
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
        localStorage.removeItem("user_role");
        return;
      }

      localStorage.setItem("access_token", response.access);
      localStorage.setItem("refresh_token", response.refresh);

      if (response.user && response.user.rol) {
        localStorage.setItem("user_role", response.user.rol);
      } else {
        console.error("❌ Error: No se pudo obtener el rol del usuario.");
        setError("No se pudo obtener el rol del usuario.");
        return;
      }

      console.log("✅ Login exitoso. Redirigiendo...");
      navigate("/dashboard", { replace: true });

    } catch (error) {
      console.error("🔴 Error en login:", error);
      setError("⚠️ No se pudo conectar con el servidor.");
      localStorage.removeItem("access_token");
      localStorage.removeItem("refresh_token");
      localStorage.removeItem("user_role");
    }
  };

  return (
    <Container maxWidth="sm">
      <Typography variant="h4" gutterBottom>
        Iniciar Sesión
      </Typography>

      {error && <Alert severity="error">{error}</Alert>}

      {!isCheckingAuth && (
        <form onSubmit={handleLogin}>
          <TextField
            label="Correo Electrónico"
            variant="outlined"
            fullWidth
            margin="normal"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <TextField
            label="Contraseña"
            variant="outlined"
            type="password"
            fullWidth
            margin="normal"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <Button type="submit" variant="contained" color="primary" fullWidth>
            Iniciar Sesión
          </Button>
        </form>
      )}
    </Container>
  );
};

export default LoginForm;
