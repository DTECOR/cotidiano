// src/components/RegistrarOrden.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button, TextField, Select, MenuItem, InputLabel, FormControl, Grid } from '@mui/material';

const RegistrarOrden = () => {
  const [productos, setProductos] = useState([]);
  const [productosSeleccionados, setProductosSeleccionados] = useState([]);
  const [cantidades, setCantidades] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    // Cargar productos disponibles desde el backend
    axios.get('/api/productos/')
      .then(response => setProductos(response.data))
      .catch(err => console.error(err));
  }, []);

  const handleProductoChange = (e, index) => {
    const newProductos = [...productosSeleccionados];
    newProductos[index] = e.target.value;
    setProductosSeleccionados(newProductos);
  };

  const handleCantidadChange = (e, index) => {
    const newCantidades = [...cantidades];
    newCantidades[index] = e.target.value;
    setCantidades(newCantidades);
  };

  const handleSubmit = () => {
    if (productosSeleccionados.length === 0 || cantidades.length === 0) {
      setError('Por favor, seleccione productos y cantidades.');
      return;
    }

    // Enviar la orden al backend
    const productosData = productosSeleccionados.map((productoId, index) => ({
      producto: productoId,
      cantidad: cantidades[index],
    }));

    axios.post('/api/ordenes/', { productos: productosData, cantidades: cantidades })
      .then(response => {
        alert('Orden registrada con éxito');
        setProductosSeleccionados([]);
        setCantidades([]);
      })
      .catch(err => {
        console.error(err);
        setError('Error al registrar la orden.');
      });
  };

  return (
    <div>
      <h2>Registrar Orden</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      
      {productosSeleccionados.map((_, index) => (
        <Grid container spacing={2} key={index}>
          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel>Producto</InputLabel>
              <Select
                value={productosSeleccionados[index] || ''}
                onChange={(e) => handleProductoChange(e, index)}
                label="Producto"
              >
                {productos.map((producto) => (
                  <MenuItem key={producto.id} value={producto.id}>
                    {producto.nombre}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6}>
            <TextField
              label="Cantidad"
              type="number"
              value={cantidades[index] || ''}
              onChange={(e) => handleCantidadChange(e, index)}
              fullWidth
            />
          </Grid>
        </Grid>
      ))}
      
      <Button onClick={() => {
        setProductosSeleccionados([...productosSeleccionados, '']);
        setCantidades([...cantidades, '']);
      }}>Agregar Producto</Button>

      <Button onClick={handleSubmit} variant="contained" color="primary">
        Registrar Orden
      </Button>
    </div>
  );
};

export default RegistrarOrden;
