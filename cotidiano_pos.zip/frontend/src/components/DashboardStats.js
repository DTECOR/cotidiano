import React, { useEffect, useState } from "react";
import api from "../services/api";
import {
    Card,
    CardContent,
    Typography,
    Grid,
    CircularProgress,
    Alert,
    Box,
    Button,
    Modal
} from "@mui/material";
import FormularioIngrediente from "./FormularioIngrediente"; // ✅ Importar el formulario

const DashboardStats = () => {
    const [datos, setDatos] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [open, setOpen] = useState(false); // Estado para manejar el modal

    useEffect(() => {
        const fetchDashboardData = async () => {
            try {
                const token = localStorage.getItem("access_token");
                if (!token) throw new Error("No hay token de autenticación.");

                const response = await api.get("/dashboard/", {
                    headers: { Authorization: `Bearer ${token}` }
                });

                setDatos(response.data);
            } catch (error) {
                console.error("Error al obtener datos del dashboard:", error);
                setError("No se pudo cargar la información del dashboard.");
            } finally {
                setLoading(false);
            }
        };

        fetchDashboardData();
    }, []);

    if (loading) return <CircularProgress style={{ margin: "20px auto", display: "block" }} />;
    if (error) return <Alert severity="error" style={{ margin: "20px" }}>{error}</Alert>;

    return (
        <Box
            sx={{
                padding: "20px",
                marginLeft: "260px",
                backgroundColor: "#f4f4f9",
                minHeight: "100vh",
            }}
        >
            <Typography variant="h4" gutterBottom sx={{ fontWeight: "bold", color: "#333" }}>
                Dashboard
            </Typography>

            <Grid container spacing={3}>
                {/* 📌 Ventas del Día */}
                <Grid item xs={12} md={4}>
                    <Card sx={{ backgroundColor: "#007bff", color: "white", boxShadow: 3, borderRadius: 3 }}>
                        <CardContent>
                            <Typography variant="h6">Ventas del Día</Typography>
                            <Typography variant="h4">${datos.ventas_hoy}</Typography>
                        </CardContent>
                    </Card>
                </Grid>

                {/* 📌 Estado de Órdenes */}
                <Grid item xs={12} md={4}>
                    <Card sx={{ backgroundColor: "#28a745", color: "white", boxShadow: 3, borderRadius: 3 }}>
                        <CardContent>
                            <Typography variant="h6">Órdenes</Typography>
                            {datos.ordenes.map((estado, index) => (
                                <Typography key={index}>{estado.estado}: {estado.total}</Typography>
                            ))}
                        </CardContent>
                    </Card>
                </Grid>

                {/* 📌 Platos Más Vendidos */}
                <Grid item xs={12} md={4}>
                    <Card sx={{ backgroundColor: "#ffc107", color: "#333", boxShadow: 3, borderRadius: 3 }}>
                        <CardContent>
                            <Typography variant="h6">Platos Más Vendidos</Typography>
                            {datos.platos_mas_vendidos.map((plato, index) => (
                                <Typography key={index}>{plato.producto__nombre}: {plato.total_vendidos}</Typography>
                            ))}
                        </CardContent>
                    </Card>
                </Grid>

                {/* 📌 Ingredientes en Bajo Stock */}
                <Grid item xs={12}>
                    <Card sx={{ backgroundColor: "#dc3545", color: "white", boxShadow: 3, borderRadius: 3 }}>
                        <CardContent>
                            <Typography variant="h6">Ingredientes en Bajo Stock</Typography>
                            {datos.ingredientes_bajo_stock.length === 0 ? (
                                <Typography>No hay ingredientes en bajo stock</Typography>
                            ) : (
                                datos.ingredientes_bajo_stock.map((ingrediente, index) => (
                                    <Typography key={index}>{ingrediente.nombre}: {ingrediente.stock} unidades</Typography>
                                ))
                            )}

                            {/* 📌 Botón para Agregar Ingredientes */}
                            <Button
                                variant="contained"
                                color="secondary"
                                onClick={() => setOpen(true)}
                                sx={{ mt: 2 }}
                            >
                                Agregar Ingrediente
                            </Button>
                        </CardContent>
                    </Card>
                </Grid>
            </Grid>

            {/* 📌 Modal para registrar un nuevo ingrediente */}
            <Modal open={open} onClose={() => setOpen(false)}>
                <Box sx={{ backgroundColor: "white", padding: 4, borderRadius: 2, width: "400px", margin: "auto", mt: 10 }}>
                    <FormularioIngrediente onClose={() => setOpen(false)} />
                </Box>
            </Modal>
        </Box>
    );
};

export default DashboardStats;
