import React from 'react';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';  // Asegúrate de importar useNavigate

const AdminPanel = () => {
  const navigate = useNavigate();  // Usa useNavigate en lugar de useHistory

  const handleGestionMenu = () => {
    navigate('/gestion-menu');  // Usa navigate() para redirigir
  };

  return (
    <div>
      <h2>Panel de Administración</h2>
      <Button variant="contained" color="primary" onClick={handleGestionMenu}>
        Gestionar Menú Diario
      </Button>
    </div>
  );
};

export default AdminPanel;
