import React, { useState } from "react";
import { TextField, Button, MenuItem, Box } from "@mui/material";
import { agregarIngrediente } from "../services/api";

const FormularioIngrediente = ({ onClose }) => {
    const [ingrediente, setIngrediente] = useState("");
    const [cantidad, setCantidad] = useState("");
    const [unidad, setUnidad] = useState("kilos");
    const [precio, setPrecio] = useState("");

    const unidades = ["unidades", "libras", "kilos", "bolsa", "paquete"];

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!ingrediente || !cantidad || !unidad || !precio) {
            alert("⚠️ Todos los campos son obligatorios.");
            return;
        }

        try {
            const nuevoIngrediente = {
                nombre: ingrediente, 
                cantidad: parseFloat(cantidad),  // ✅ Convertir a número
                unidad: unidad,
                precio: parseFloat(precio),  // ✅ Convertir a número
                stock: parseFloat(cantidad),  // ✅ Se asigna stock igual a cantidad
            };

            console.log("📤 Enviando datos al backend:", nuevoIngrediente);  // ✅ Verificar datos antes de enviarlos

            await agregarIngrediente(nuevoIngrediente);
            alert("✅ Ingrediente agregado correctamente.");
            onClose();
        } catch (error) {
            alert("❌ Error al agregar ingrediente. Revisa la consola.");
            console.error("Error en handleSubmit:", error);
        }
    };

    return (
        <Box component="form" onSubmit={handleSubmit}>
            <TextField
                label="Ingrediente"
                fullWidth
                value={ingrediente}
                onChange={(e) => setIngrediente(e.target.value)}
                required
            />
            <TextField
                label="Cantidad"
                fullWidth
                type="number"
                value={cantidad}
                onChange={(e) => setCantidad(e.target.value)}
                required
            />
            <TextField
                select
                label="Unidad"
                fullWidth
                value={unidad}
                onChange={(e) => setUnidad(e.target.value)}
                required
            >
                {unidades.map((u) => (
                    <MenuItem key={u} value={u}>{u}</MenuItem>
                ))}
            </TextField>
            <TextField
                label="Precio"
                fullWidth
                type="number"
                value={precio}
                onChange={(e) => setPrecio(e.target.value)}
                required
            />
            <Button type="submit" variant="contained" sx={{ mt: 2 }}>
                Guardar
            </Button>
        </Box>
    );
};

export default FormularioIngrediente;
