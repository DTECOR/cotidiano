import React, { useState, useEffect } from "react";
import Axios from "axios";
import { Button, Table, TableContainer, TableHead, TableRow, TableCell, TableBody, Paper } from "@mui/material";

const GestionMenu = () => {
  const [ingredientes, setIngredientes] = useState([]);
  const [menuSeleccionado, setMenuSeleccionado] = useState([]);
  const [error, setError] = useState("");

  // Obtener los ingredientes disponibles
  useEffect(() => {
    Axios.get("http://localhost:8000/api/ingredientes/", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,  // Asegúrate de usar el token adecuado
      },
    })
      .then((response) => {
        setIngredientes(response.data);
      })
      .catch((err) => {
        setError("No se pudieron cargar los ingredientes.");
      });
  }, []);

  // Función para manejar la creación del menú
  const crearMenu = () => {
    if (menuSeleccionado.length === 0) {
      setError("Debes seleccionar al menos un ingrediente para el menú.");
      return;
    }

    // Enviar los ingredientes seleccionados para crear el menú
    Axios.post(
      "http://localhost:8000/api/menu/diario/",  // Ruta para definir el menú diario
      {
        platos: menuSeleccionado,
      },
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      }
    )
      .then((response) => {
        alert("Menú creado exitosamente.");
      })
      .catch((err) => {
        setError("Hubo un error al crear el menú.");
      });
  };

  return (
    <div>
      <h2>Gestión del Menú Diario</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Ingrediente</TableCell>
              <TableCell>Cantidad Disponible</TableCell>
              <TableCell>Seleccionar</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {ingredientes.map((ingrediente) => (
              <TableRow key={ingrediente.id}>
                <TableCell>{ingrediente.nombre}</TableCell>
                <TableCell>{ingrediente.stock}</TableCell>
                <TableCell>
                  <input
                    type="checkbox"
                    value={ingrediente.id}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setMenuSeleccionado([...menuSeleccionado, ingrediente.id]);
                      } else {
                        setMenuSeleccionado(menuSeleccionado.filter(id => id !== ingrediente.id));
                      }
                    }}
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Button onClick={crearMenu} variant="contained" color="primary" style={{ marginTop: "20px" }}>
        Crear Menú Diario
      </Button>
    </div>
  );
};

export default GestionMenu;
