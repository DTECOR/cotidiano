import React, { useEffect, useState } from "react";
import api from "../services/api";
import {
  Container, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Paper, Typography, Button, CircularProgress
} from "@mui/material";
import { useNavigate } from "react-router-dom";

const Ordenes = () => {
  const [ordenes, setOrdenes] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true); // ✅ Estado para carga de datos
  const navigate = useNavigate();
  const rol = localStorage.getItem("user_role"); // ✅ Se asegura de recuperar el rol del usuario
  const token = localStorage.getItem("access_token"); // ✅ Se obtiene el token de autenticación

  useEffect(() => {
    fetchOrdenes();
  }, []);

  const fetchOrdenes = async () => {
    if (!token) {
      setError("No estás autenticado. Inicia sesión nuevamente.");
      setLoading(false);
      return;
    }

    try {
      const response = await api.get("/ordenes/", {
        headers: { Authorization: `Bearer ${token}` }, // ✅ Se añade el token de autenticación
      });
      setOrdenes(response.data);
    } catch (error) {
      console.error("Error cargando órdenes:", error);
      setError("Error cargando las órdenes. Verifica tu conexión o permisos.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container style={{ marginTop: "20px" }}>
      <Typography variant="h4" gutterBottom>
        Órdenes
      </Typography>

      {loading ? (
        <CircularProgress />
      ) : (
        <>
          {rol === "COCINERO" && (
            <Button
              variant="contained"
              color="primary"
              style={{ marginBottom: "20px" }}
              onClick={() => navigate("/menu-cocinero")}
            >
              Gestionar Menú del Día
            </Button>
          )}

          {rol === "CAJERO" && (
            <Button
              variant="contained"
              color="primary"
              style={{ marginBottom: "20px", marginLeft: "10px" }}
              onClick={() => navigate("/facturacion")}
            >
              Ir a Facturación
            </Button>
          )}

          {error && <Typography color="error">{error}</Typography>}

          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>ID</TableCell>
                  <TableCell>Estado</TableCell>
                  <TableCell>Mesero</TableCell>
                  <TableCell>Fecha</TableCell>
                  <TableCell>Acciones</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {ordenes.length > 0 ? (
                  ordenes.map((orden) => (
                    <TableRow key={orden.id}>
                      <TableCell>{orden.id}</TableCell>
                      <TableCell>{orden.estado}</TableCell>
                      <TableCell>{orden.mesero || "No asignado"}</TableCell>
                      <TableCell>{new Date(orden.fecha).toLocaleString()}</TableCell>
                      <TableCell>
                        <Button
                          variant="contained"
                          color="secondary"
                          onClick={() => navigate(`/ordenes/${orden.id}`)}
                        >
                          Ver Detalle
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} align="center">
                      No hay órdenes disponibles.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>

          <Button
            variant="contained"
            color="secondary"
            style={{ marginTop: "20px" }}
            onClick={() => navigate("/dashboard")}
          >
            Volver al Dashboard
          </Button>
        </>
      )}
    </Container>
  );
};

export default Ordenes;
