import { useState, useEffect } from "react";

export const useAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isSuperUser, setIsSuperUser] = useState(false);

  useEffect(() => {
    const token = sessionStorage.getItem("access");
    const isSuper = sessionStorage.getItem("isSuperUser") === "true";

    setIsAuthenticated(!!token);
    setIsSuperUser(isSuper);
  }, []);

  return { isAuthenticated, isSuperUser };
};
