import axios from "axios";

const API_BASE_URL = "http://127.0.0.1:8000/api"; // ✅ URL base corregida

// 🔹 Función para obtener el almacenamiento seguro
const getStorage = () => {
  if (typeof window === "undefined") return null;
  try {
    return window.sessionStorage ?? window.localStorage;
  } catch (error) {
    console.error("🔴 No se puede acceder al almacenamiento:", error);
    return null;
  }
};

const storage = getStorage();

// 🔹 Función segura para obtener el token de acceso
const getAccessToken = () => {
  if (!storage) return null;
  try {
    return storage.getItem("access_token");
  } catch (error) {
    console.error("🔴 Error accediendo al almacenamiento:", error);
    return null;
  }
};

// 🔹 Configuración de Axios con la API base
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: { "Content-Type": "application/json" },
});

// 🔹 Interceptor para agregar el token antes de cada solicitud
api.interceptors.request.use(
  async (config) => {
    const token = getAccessToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// 🔹 Interceptor para manejar errores de autenticación sin bucles infinitos
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      console.warn("🔴 Sesión expirada. Eliminando tokens...");

      // ✅ Se eliminan tokens sin hacer otra petición a la API
      storage?.removeItem("access_token");
      storage?.removeItem("refresh_token");
      storage?.removeItem("user_role");

      // Redirigir manualmente al login si estamos en el entorno del navegador
      if (typeof window !== "undefined") {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

// 🔹 Manejo seguro del login
export const login = async (email, password) => {
  try {
    if (!storage) throw new Error("No se puede acceder al almacenamiento");

    // ✅ Se corrigió '/api/login/' a '/api/token/'
    const response = await api.post("/token/", { email, password });

    if (!response.data.access) {
      throw new Error("Credenciales incorrectas o problema de conexión.");
    }

    const userRole = response.data.user ? response.data.user.rol : null;
    if (!userRole) {
      throw new Error("No se pudo obtener el rol del usuario.");
    }

    // ✅ Guardamos tokens en sessionStorage de forma segura
    storage.setItem("access_token", response.data.access);
    storage.setItem("refresh_token", response.data.refresh);
    storage.setItem("user_role", userRole);

    console.log("✅ Login exitoso. Tokens guardados.");
    return response.data;
  } catch (error) {
    console.error("🔴 Error en login:", error.response?.data || error.message);
    throw new Error("⚠️ Usuario o contraseña incorrectos.");
  }
};

// 🔹 Logout con eliminación segura de tokens sin bucles infinitos
export const logout = async () => {
  if (!storage) return;

  try {
    const refreshToken = storage.getItem("refresh_token");

    if (refreshToken) {
      await api.post("/logout/", { refresh: refreshToken }).catch(() => {
        console.warn("🔴 Error al invalidar el token en el servidor.");
      });
    }

    console.log("👋 Cierre de sesión exitoso. Eliminando tokens...");

    // 🔹 Eliminar tokens de sessionStorage y localStorage
    storage.removeItem("access_token");
    storage.removeItem("refresh_token");
    storage.removeItem("user_role");

    // Redirigir a login
    if (typeof window !== "undefined") {
      window.location.href = "/login";
    }
  } catch (error) {
    console.error("🔴 Error en logout:", error);
  }
};

// 🔹 Función para agregar un nuevo ingrediente
export const agregarIngrediente = async (data) => {
  try {
    const token = localStorage.getItem("access_token"); // ✅ Obtener token correctamente
    const response = await api.post("/ingredientes/", data, {
      headers: { 
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      }
    });

    console.log("✅ Ingrediente agregado:", response.data);
    return response.data;
  } catch (error) {
    console.error("🔴 Error al agregar ingrediente:", error.response?.data || error.message);
    throw error;
  }
};

// 🔹 Función para obtener órdenes con manejo de errores
export const getOrdenes = async () => {
  try {
    const response = await api.get("/ordenes/");
    return response.data;
  } catch (error) {
    console.error("Error obteniendo órdenes:", error);
    throw error;
  }
};

// 🔹 Función para obtener inventario solo para el administrador
export const getInventario = async () => {
  try {
    const response = await api.get("/inventario/");
    return response.data;
  } catch (error) {
    console.error("Error obteniendo inventario:", error);
    throw error;
  }
};

// 🔹 Función para obtener el menú del día solo para cocineros
export const getMenuDiario = async () => {
  try {
    const response = await api.get("/menu-diario/");
    return response.data;
  } catch (error) {
    console.error("Error obteniendo menú diario:", error);
    throw error;
  }
};

// 🔹 Función para obtener usuarios solo para administradores
export const getUsuarios = async () => {
  try {
    const response = await api.get("/usuarios/");
    return response.data;
  } catch (error) {
    console.error("Error obteniendo usuarios:", error);
    throw error;
  }
};

// 🔹 Función para crear un nuevo usuario (solo para administradores)
export const createUsuario = async (nuevoUsuario) => {
  try {
    const response = await api.post("/usuarios/", nuevoUsuario);
    return response.data;
  } catch (error) {
    console.error("Error creando usuario:", error);
    throw error;
  }
};

export default api;
