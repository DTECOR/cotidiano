import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { TextField, Button, Container, Typography, Alert } from "@mui/material";

const LoginForm = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        setError(null); // Resetear error al intentar nuevamente

        try {
            const response = await axios.post("http://127.0.0.1:8000/api/login/", { email, password });

            // ✅ Guardar el token y el rol del usuario en localStorage
            localStorage.setItem("access_token", response.data.access);
            localStorage.setItem("user_role", response.data.role);

            // 🚀 Solo redirigir si el token existe
            if (response.data.access) {
                navigate("/dashboard");
            }
        } catch (err) {
            setError("Error al iniciar sesión. Verifica tus credenciales.");
        }
    };

    return (
        <Container maxWidth="xs">
            <Typography variant="h4" gutterBottom>
                Iniciar Sesión
            </Typography>
            
            {error && <Alert severity="error">{error}</Alert>}

            <form onSubmit={handleLogin}>
                <TextField
                    label="Correo Electrónico"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                <TextField
                    label="Contraseña"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <Button type="submit" variant="contained" color="primary" fullWidth sx={{ mt: 2 }}>
                    Iniciar Sesión
                </Button>
            </form>
        </Container>
    );
};

export default LoginForm;
