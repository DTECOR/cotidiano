import React, { useEffect, useState } from "react";
import api from "../services/api";
import {
  Container, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Paper, Button, Dialog, DialogActions,
  DialogContent, DialogTitle, TextField, Select, MenuItem, Typography, CircularProgress
} from "@mui/material";
import { useNavigate } from "react-router-dom";

const AdminUsuarios = () => {
  const [usuarios, setUsuarios] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [nuevoUsuario, setNuevoUsuario] = useState({
    username: "",
    email: "",
    password: "",
    rol: "",
  });
  const navigate = useNavigate();
  const token = localStorage.getItem("access_token"); // ✅ Se obtiene el token de autenticación

  useEffect(() => {
    fetchUsuarios();
  }, []);

  const fetchUsuarios = async () => {
    if (!token) {
      setError("No estás autenticado. Inicia sesión nuevamente.");
      setLoading(false);
      return;
    }

    try {
      const response = await api.get("/usuarios/", {
        headers: { Authorization: `Bearer ${token}` }, // ✅ Se añade autenticación en la petición
      });
      setUsuarios(response.data);
    } catch (error) {
      console.error("Error cargando usuarios:", error);
      setError("Error cargando los usuarios. Verifica tu conexión o permisos.");
    } finally {
      setLoading(false);
    }
  };

  const handleAgregarUsuario = async () => {
    try {
      if (!nuevoUsuario.rol) {
        alert("Debes seleccionar un rol para el nuevo usuario.");
        return;
      }

      await api.post("/usuarios/", nuevoUsuario, {
        headers: { Authorization: `Bearer ${token}` }, // ✅ Se envía el token en la solicitud
      });
      fetchUsuarios();
      setOpen(false);
      setNuevoUsuario({ username: "", email: "", password: "", rol: "" });
    } catch (error) {
      console.error("Error creando usuario", error);
      setError("Error al crear usuario. Verifica los datos.");
    }
  };

  return (
    <Container style={{ marginTop: "20px" }}>
      <Typography variant="h4" gutterBottom>
        Gestión de Usuarios
      </Typography>

      {loading ? (
        <CircularProgress />
      ) : (
        <>
          <Button
            variant="contained"
            color="primary"
            style={{ marginBottom: "20px" }}
            onClick={() => setOpen(true)}
          >
            Agregar Usuario
          </Button>

          {error && <Typography color="error">{error}</Typography>}

          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>ID</TableCell>
                  <TableCell>Nombre</TableCell>
                  <TableCell>Email</TableCell>
                  <TableCell>Rol</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {usuarios.length > 0 ? (
                  usuarios.map((Usuario) => (
                    <TableRow key={Usuario.id}>
                      <TableCell>{Usuario.id}</TableCell>
                      <TableCell>{Usuario.username}</TableCell>
                      <TableCell>{Usuario.email}</TableCell>
                      <TableCell>{Usuario.rol}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} align="center">
                      No hay usuarios registrados.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>

          {/* Diálogo para agregar usuario */}
          <Dialog open={open} onClose={() => setOpen(false)}>
            <DialogTitle>Agregar Usuario</DialogTitle>
            <DialogContent>
              <TextField
                label="Nombre de Usuario"
                fullWidth
                margin="normal"
                value={nuevoUsuario.username}
                onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, username: e.target.value })}
              />
              <TextField
                label="Email"
                fullWidth
                margin="normal"
                value={nuevoUsuario.email}
                onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, email: e.target.value })}
              />
              <TextField
                label="Contraseña"
                fullWidth
                margin="normal"
                type="password"
                value={nuevoUsuario.password}
                onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, password: e.target.value })}
              />
              <Select
                fullWidth
                value={nuevoUsuario.rol}
                onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, rol: e.target.value })}
                displayEmpty
              >
                <MenuItem value="" disabled>Seleccionar Rol</MenuItem>
                <MenuItem value="ADMIN">Administrador</MenuItem>
                <MenuItem value="MESERO">Mesero</MenuItem>
                <MenuItem value="COCINERO">Cocinero</MenuItem>
                <MenuItem value="CAJERO">Cajero</MenuItem>
              </Select>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setOpen(false)}>Cancelar</Button>
              <Button onClick={handleAgregarUsuario} variant="contained" color="primary">
                Agregar
              </Button>
            </DialogActions>
          </Dialog>

          <Button
            variant="contained"
            color="secondary"
            style={{ marginTop: "20px" }}
            onClick={() => navigate("/dashboard")}
          >
            Volver al Dashboard
          </Button>
        </>
      )}
    </Container>
  );
};

export default AdminUsuarios;
