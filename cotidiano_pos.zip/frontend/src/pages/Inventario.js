import React, { useEffect, useState } from "react";
import api from "../services/api";
import {
  Container, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Paper, Button, Typography, Dialog, DialogActions, DialogContent, DialogTitle,
  TextField, CircularProgress, Alert, Box
} from "@mui/material";
import { useNavigate } from "react-router-dom";

const Inventario = () => {
  const [inventario, setInventario] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [open, setOpen] = useState(false);
  const [nuevoIngrediente, setNuevoIngrediente] = useState({
    nombre: "",
    cantidad: "",
    unidad: "",
    costo: "",
    fecha_compra: "",
  });
  const navigate = useNavigate();

  useEffect(() => {
    fetchInventario();
  }, []);

  // 🔹 Obtener datos del inventario
  const fetchInventario = async () => {
    try {
      const response = await api.get("/inventario/");
      setInventario(response.data);
    } catch (error) {
      console.error("Error obteniendo inventario:", error);
      setError("No se pudo cargar el inventario.");
    } finally {
      setLoading(false);
    }
  };

  // 🔹 Agregar nuevo ingrediente al inventario
  const handleAgregarIngrediente = async () => {
    try {
      await api.post("/inventario/", nuevoIngrediente);
      fetchInventario();
      setOpen(false);
      setNuevoIngrediente({ nombre: "", cantidad: "", unidad: "", costo: "", fecha_compra: "" });
    } catch (error) {
      console.error("Error agregando ingrediente:", error);
      setError("No se pudo agregar el ingrediente.");
    }
  };

  if (loading) return <CircularProgress style={{ margin: "20px auto", display: "block" }} />;
  if (error) return <Alert severity="error" style={{ margin: "20px" }}>{error}</Alert>;

  return (
    <Box sx={{ padding: "20px", marginLeft: "260px", backgroundColor: "#f4f4f9", minHeight: "100vh" }}>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: "bold", color: "#333" }}>
        Gestión de Inventario 📦
      </Typography>

      <Button
        variant="contained"
        color="primary"
        sx={{ marginBottom: "20px" }}
        onClick={() => setOpen(true)}
      >
        ➕ Agregar Ingrediente
      </Button>

      {/* 📌 Tabla de Inventario */}
      <TableContainer component={Paper} sx={{ borderRadius: "10px", boxShadow: 3 }}>
        <Table>
          <TableHead>
            <TableRow sx={{ backgroundColor: "#007bff" }}>
              <TableCell sx={{ color: "white", fontWeight: "bold" }}>Ingrediente</TableCell>
              <TableCell sx={{ color: "white", fontWeight: "bold" }}>Cantidad Disponible</TableCell>
              <TableCell sx={{ color: "white", fontWeight: "bold" }}>Unidad</TableCell>
              <TableCell sx={{ color: "white", fontWeight: "bold" }}>Costo</TableCell>
              <TableCell sx={{ color: "white", fontWeight: "bold" }}>Fecha de Compra</TableCell>
              <TableCell sx={{ color: "white", fontWeight: "bold" }}>Registrado por</TableCell>
              <TableCell sx={{ color: "white", fontWeight: "bold" }}>Cantidad Usada</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {inventario.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} align="center">
                  No hay ingredientes registrados en el inventario.
                </TableCell>
              </TableRow>
            ) : (
              inventario.map((ingrediente) => (
                <TableRow key={ingrediente.id}>
                  <TableCell>{ingrediente.nombre}</TableCell>
                  <TableCell>{ingrediente.cantidad}</TableCell>
                  <TableCell>{ingrediente.unidad}</TableCell>
                  <TableCell>${ingrediente.costo}</TableCell>
                  <TableCell>{new Date(ingrediente.fecha_compra).toLocaleDateString()}</TableCell>
                  <TableCell>{ingrediente.usuario_registro}</TableCell>
                  <TableCell>{ingrediente.cantidad_usada}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* 📌 Diálogo para agregar ingrediente */}
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>➕ Agregar Nuevo Ingrediente</DialogTitle>
        <DialogContent>
          <TextField
            label="Nombre"
            fullWidth
            margin="normal"
            value={nuevoIngrediente.nombre}
            onChange={(e) => setNuevoIngrediente({ ...nuevoIngrediente, nombre: e.target.value })}
          />
          <TextField
            label="Cantidad"
            fullWidth
            margin="normal"
            type="number"
            value={nuevoIngrediente.cantidad}
            onChange={(e) => setNuevoIngrediente({ ...nuevoIngrediente, cantidad: e.target.value })}
          />
          <TextField
            label="Unidad (kg, lb, unidades, etc.)"
            fullWidth
            margin="normal"
            value={nuevoIngrediente.unidad}
            onChange={(e) => setNuevoIngrediente({ ...nuevoIngrediente, unidad: e.target.value })}
          />
          <TextField
            label="Costo ($)"
            fullWidth
            margin="normal"
            type="number"
            value={nuevoIngrediente.costo}
            onChange={(e) => setNuevoIngrediente({ ...nuevoIngrediente, costo: e.target.value })}
          />
          <TextField
            label="Fecha de Compra"
            fullWidth
            margin="normal"
            type="date"
            value={nuevoIngrediente.fecha_compra}
            onChange={(e) => setNuevoIngrediente({ ...nuevoIngrediente, fecha_compra: e.target.value })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={handleAgregarIngrediente} variant="contained" color="primary">
            Agregar
          </Button>
        </DialogActions>
      </Dialog>

      {/* 📌 Botón: Volver al Dashboard */}
      <Button
        variant="contained"
        color="secondary"
        sx={{ marginTop: "20px" }}
        onClick={() => navigate("/dashboard")}
      >
        🔙 Volver al Dashboard
      </Button>
    </Box>
  );
};

export default Inventario;
