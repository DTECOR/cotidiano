import React, { useEffect, useState } from "react";
import api from "../services/api";
import {
  Container, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Paper, Button, Typography, TextField, Alert
} from "@mui/material";
import { useNavigate } from "react-router-dom";

const Facturacion = () => {
  const [ordenes, setOrdenes] = useState([]);
  const [ventasTotales, setVentasTotales] = useState(0);
  const [ventasDiarias, setVentasDiarias] = useState(0);
  const [ventasSemanales, setVentasSemanales] = useState(0);
  const [ventasMensuales, setVentasMensuales] = useState(0);
  const [pago, setPago] = useState({});
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchOrdenes();
    fetchResumenVentas();
  }, []);

  // 🔹 Obtener todas las órdenes
  const fetchOrdenes = async () => {
    try {
      const response = await api.get("/ordenes/");
      setOrdenes(response.data);
    } catch (error) {
      console.error("Error obteniendo órdenes:", error);
      setError("Error cargando las órdenes.");
    }
  };

  // 🔹 Obtener resumen de ventas
  const fetchResumenVentas = async () => {
    try {
      const response = await api.get("/facturacion/resumen/");
      setVentasTotales(response.data.total);
      setVentasDiarias(response.data.diario);
      setVentasSemanales(response.data.semanal);
      setVentasMensuales(response.data.mensual);
    } catch (error) {
      console.error("Error obteniendo resumen de ventas:", error);
      setError("Error cargando el resumen de ventas.");
    }
  };

  // 🔹 Registrar pago de una orden
  const handlePago = async (ordenId) => {
    try {
      await api.post(`/facturacion/`, { orden_id: ordenId, monto: pago[ordenId] || 0 });
      fetchOrdenes();
      fetchResumenVentas();
    } catch (error) {
      console.error("Error procesando el pago:", error);
      setError("Error al procesar el pago.");
    }
  };

  // 🔹 Generar reporte de ventas según el periodo
  const generarReporte = async (periodo) => {
    try {
      const response = await api.get(`/facturacion/reporte/${periodo}/`);
      console.log("🔹 Reporte generado:", response.data);
      alert(`✅ Reporte generado para ${periodo}`);
    } catch (error) {
      console.error("Error generando reporte:", error);
      alert("⚠️ No se pudo generar el reporte.");
    }
  };

  return (
    <Container>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: "bold" }}>
        Módulo de Facturación 💰
      </Typography>

      {error && <Alert severity="error">{error}</Alert>}

      {/* 📌 Resumen de Ventas */}
      <Typography variant="h5" sx={{ marginTop: 3, color: "#007bff" }}>
        Resumen de Ventas
      </Typography>
      <TableContainer component={Paper} sx={{ marginBottom: 3 }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Total Vendido</TableCell>
              <TableCell>Ventas del Día</TableCell>
              <TableCell>Ventas Semanales</TableCell>
              <TableCell>Ventas Mensuales</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            <TableRow>
              <TableCell>${ventasTotales}</TableCell>
              <TableCell>${ventasDiarias}</TableCell>
              <TableCell>${ventasSemanales}</TableCell>
              <TableCell>${ventasMensuales}</TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>

      {/* 📌 Botones de Reportes */}
      <Typography variant="h5" sx={{ marginTop: 3, color: "#28a745" }}>
        Reportes y Gestión
      </Typography>
      <Button variant="contained" color="primary" sx={{ marginRight: 2 }} onClick={() => generarReporte("diario")}>
        📅 Reporte Diario
      </Button>
      <Button variant="contained" color="primary" sx={{ marginRight: 2 }} onClick={() => generarReporte("semanal")}>
        📆 Reporte Semanal
      </Button>
      <Button variant="contained" color="primary" sx={{ marginRight: 2 }} onClick={() => generarReporte("mensual")}>
        📊 Reporte Mensual
      </Button>
      <Button variant="contained" color="secondary" sx={{ marginTop: 2 }} onClick={() => generarReporte("personalizado")}>
        📜 Reporte Personalizado
      </Button>

      {/* 📌 Tabla de Órdenes Pendientes de Pago */}
      <Typography variant="h5" sx={{ marginTop: 3, color: "#dc3545" }}>
        Órdenes Pendientes de Pago
      </Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Cliente</TableCell>
              <TableCell>Total</TableCell>
              <TableCell>Estado</TableCell>
              <TableCell>Monto a Pagar</TableCell>
              <TableCell>Acciones</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {ordenes.filter(orden => orden.estado !== "PAGADO").map((orden) => (
              <TableRow key={orden.id}>
                <TableCell>{orden.id}</TableCell>
                <TableCell>{orden.cliente}</TableCell>
                <TableCell>${orden.total}</TableCell>
                <TableCell>{orden.estado}</TableCell>
                <TableCell>
                  <TextField
                    type="number"
                    value={pago[orden.id] || ""}
                    onChange={(e) => setPago({ ...pago, [orden.id]: e.target.value })}
                    variant="outlined"
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => handlePago(orden.id)}
                  >
                    Registrar Pago
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* 📌 Botón: Volver al Dashboard */}
      <Button
        variant="contained"
        color="secondary"
        sx={{ marginTop: 3 }}
        onClick={() => navigate("/dashboard")}
      >
        🔙 Volver al Dashboard
      </Button>
    </Container>
  );
};

export default Facturacion;
