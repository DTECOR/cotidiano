import React, { useEffect, useState } from "react";
import api from "../services/api";
import {
  Container, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Paper, Button, Typography, Alert
} from "@mui/material";
import { useNavigate } from "react-router-dom";

const MenuCocinero = () => {
  const [menu, setMenu] = useState([]);
  const [productos, setProductos] = useState([]);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchMenu();
    fetchProductos();
  }, []);

  // 🔹 Obtener el menú diario con ingredientes incluidos
  const fetchMenu = async () => {
    try {
      const response = await api.get("/menu-diario/");
      setMenu(response.data);
    } catch (error) {
      console.error("Error cargando el menú:", error);
      setError("No se pudo cargar el menú.");
    }
  };

  // 🔹 Obtener todos los productos disponibles
  const fetchProductos = async () => {
    try {
      const response = await api.get("/productos/");
      setProductos(response.data);
    } catch (error) {
      console.error("Error obteniendo productos:", error);
    }
  };

  // 🔹 Agregar un producto al menú
  const handleAgregarPlato = async (productoId) => {
    try {
      await api.post("/menu-diario/", { productos: [productoId] });
      fetchMenu();  // 🔄 Recargar menú después de agregar
    } catch (error) {
      console.error("Error agregando plato:", error);
      setError("No se pudo agregar el plato.");
    }
  };

  return (
    <Container>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: "bold" }}>
        Gestión del Menú del Día 🍽️
      </Typography>

      {error && <Alert severity="error">{error}</Alert>}

      {/* 📌 Sección: Menú Actual */}
      <Typography variant="h5" gutterBottom sx={{ marginTop: 2, color: "#007bff" }}>
        Menú Actual
      </Typography>
      {menu.length === 0 ? (
        <Alert severity="warning">No hay platos en el menú del día.</Alert>
      ) : (
        menu.map((plato) => (
          <TableContainer component={Paper} key={plato.id} sx={{ marginBottom: 3 }}>
            <Typography variant="h6" sx={{ padding: 2 }}>{plato.nombre}</Typography>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Ingrediente</TableCell>
                  <TableCell>Cantidad Necesaria</TableCell>
                  <TableCell>Stock Disponible</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {plato.ingredientes.map((ingrediente) => (
                  <TableRow key={ingrediente.id}>
                    <TableCell>{ingrediente.nombre}</TableCell>
                    <TableCell>{ingrediente.cantidad}</TableCell>
                    <TableCell>{ingrediente.stock}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        ))
      )}

      {/* 📌 Sección: Agregar Productos */}
      <Typography variant="h5" gutterBottom sx={{ marginTop: 4, color: "#28a745" }}>
        Agregar Productos al Menú
      </Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Nombre</TableCell>
              <TableCell>Stock</TableCell>
              <TableCell>Acciones</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {productos.map((producto) => (
              <TableRow key={producto.id}>
                <TableCell>{producto.nombre}</TableCell>
                <TableCell>{producto.stock}</TableCell>
                <TableCell>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => handleAgregarPlato(producto.id)}
                    disabled={menu.some((p) => p.id === producto.id)}
                  >
                    {menu.some((p) => p.id === producto.id) ? "Ya en Menú" : "Agregar al Menú"}
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* 📌 Botón: Volver al Dashboard */}
      <Button
        variant="contained"
        color="secondary"
        sx={{ marginTop: 3 }}
        onClick={() => navigate("/dashboard")}
      >
        🔙 Volver al Dashboard
      </Button>
    </Container>
  );
};

export default MenuCocinero;
