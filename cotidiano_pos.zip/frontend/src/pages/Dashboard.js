import React from "react";
import { useNavigate } from "react-router-dom";
import { Container, Typography, Button, Grid, Paper } from "@mui/material";
import DashboardStats from "../components/DashboardStats"; // Cambiado de Dashboard a DashboardStats


const Dashboard = () => {
  const navigate = useNavigate();
  const userRole = localStorage.getItem("user_role"); // Recupera el rol del usuario

  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        Panel Principal
      </Typography>

      <Grid container spacing={3}>
        {/* Todos los usuarios pueden ver órdenes */}
        <Grid item xs={12} sm={6} md={4}>
          <Paper elevation={3} style={{ padding: "20px", textAlign: "center" }}>
            <Typography variant="h6">Órdenes</Typography>
            <Button variant="contained" color="primary" onClick={() => navigate("/ordenes")}>
              Ver Órdenes
            </Button>
          </Paper>
        </Grid>

        {/* Módulos exclusivos según el rol */}
        {userRole === "ADMIN" && (
          <>
            <Grid item xs={12} sm={6} md={4}>
              <Paper elevation={3} style={{ padding: "20px", textAlign: "center" }}>
                <Typography variant="h6">Usuarios</Typography>
                <Button variant="contained" color="secondary" onClick={() => navigate("/admin/usuarios")}>
                  Gestionar Usuarios
                </Button>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <Paper elevation={3} style={{ padding: "20px", textAlign: "center" }}>
                <Typography variant="h6">Inventario</Typography>
                <Button variant="contained" color="secondary" onClick={() => navigate("/admin/inventario")}>
                  Gestionar Inventario
                </Button>
              </Paper>
            </Grid>
          </>
        )}

        {userRole === "COCINERO" && (
          <Grid item xs={12} sm={6} md={4}>
            <Paper elevation={3} style={{ padding: "20px", textAlign: "center" }}>
              <Typography variant="h6">Menú del Día</Typography>
              <Button variant="contained" color="primary" onClick={() => navigate("/cocinero/menu")}>
                Gestionar Menú
              </Button>
            </Paper>
          </Grid>
        )}

        {userRole === "CAJERO" && (
          <Grid item xs={12} sm={6} md={4}>
            <Paper elevation={3} style={{ padding: "20px", textAlign: "center" }}>
              <Typography variant="h6">Facturación</Typography>
              <Button variant="contained" color="primary" onClick={() => navigate("/cajero/facturacion")}>
                Ir a Facturación
              </Button>
            </Paper>
          </Grid>
        )}
      </Grid>
    </Container>
  );
};

export default Dashboard;
