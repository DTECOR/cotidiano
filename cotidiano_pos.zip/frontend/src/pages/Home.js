import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getOrdenes, logout } from "../services/api";
import { Button, Container, Typography, CircularProgress, Alert } from "@mui/material";

const Home = () => {
  const [ordenes, setOrdenes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate(); 

  useEffect(() => {
    const fetchOrdenes = async () => {
      const token = sessionStorage.getItem("access") || localStorage.getItem("access");
      if (!token) {
        console.error("🔴 No hay token de acceso. Redirigiendo al login.");
        setError("Usuario no autenticado. Inicie sesión nuevamente.");
        sessionStorage.clear();
        navigate("/login");
        return;
      }

      console.log("✅ Token encontrado:", token);

      try {
        const data = await getOrdenes();
        console.log("📦 Respuesta de API:", data);

        if (!Array.isArray(data)) {
          throw new Error("La API no devolvió un array válido.");
        }

        setOrdenes(data);
        sessionStorage.setItem("orders", JSON.stringify(data)); // Almacenar en caché
      } catch (err) {
        setError("Error cargando órdenes. Intente nuevamente.");
        console.error("🔴 Error al obtener órdenes:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchOrdenes();
  }, [navigate]);

  const handleLogout = async () => {
    try {
      await logout();
    } catch (err) {
      console.error("Error cerrando sesión:", err);
    } finally {
      sessionStorage.clear();
      localStorage.removeItem("is_authenticated");
      console.log("👋 Cierre de sesión exitoso, limpiando storage.");
      window.location.href = "/login";
    }
  };

  return (
    <Container>
      <Typography variant="h4" gutterBottom>Órdenes Actuales</Typography>

      {loading ? (
        <CircularProgress />
      ) : error ? (
        <Alert severity="error">{error}</Alert>
      ) : ordenes.length === 0 ? (
        <Alert severity="info">No hay órdenes disponibles.</Alert>
      ) : (
        <ul>
          {ordenes.map((orden) => (
            <li key={orden.id}>
              <Typography variant="body1">Orden {orden.id} - Estado: {orden.estado}</Typography>
            </li>
          ))}
        </ul>
      )}

      <Button variant="contained" color="error" onClick={handleLogout}>
        Cerrar Sesión
      </Button>
    </Container>
  );
};

export default Home;
