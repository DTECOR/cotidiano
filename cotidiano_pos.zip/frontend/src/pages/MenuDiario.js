import React, { useEffect, useState } from "react";
import axios from "axios";
import { Container, Button, Typography, Checkbox, FormControlLabel } from "@mui/material";

const MenuDiario = () => {
  const [platos, setPlatos] = useState([]);  // Platos disponibles
  const [seleccionados, setSeleccionados] = useState([]);  // Platos seleccionados
  const [error, setError] = useState(null);  // Manejo de errores

  useEffect(() => {
    fetchPlatos();  // Cargar los platos al inicio
  }, []);

  // Función para obtener los platos disponibles
  const fetchPlatos = async () => {
    try {
      const response = await axios.get("http://localhost:8000/api/productos/", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('access_token')}`,  // Asegurarse de incluir el token de autenticación
        },
      });
      setPlatos(response.data.productos);  // Actualizar el estado con los productos obtenidos
    } catch (error) {
      console.error("Error obteniendo platos:", error);
      setError("No se pudieron cargar los platos.");  // Manejo de errores en el fetch
    }
  };

  // Función para manejar la selección de platos
  const handleSeleccion = (id) => {
    setSeleccionados((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]  // Alternar entre seleccionado/no seleccionado
    );
  };

  // Función para confirmar el menú
  const handleConfirmarMenu = async () => {
    if (seleccionados.length === 0) {
      setError("Debes seleccionar al menos un plato para el menú.");
      return;
    }

    try {
      const response = await axios.post("http://localhost:8000/api/menu/diario/", {
        productos: seleccionados,  // Enviar los platos seleccionados al backend
      }, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('access_token')}`,  // Asegurarse de incluir el token de autenticación
        },
      });
      alert("Menú actualizado con éxito.");
    } catch (error) {
      setError(error.response?.data?.error || "Hubo un error al actualizar el menú.");  // Mostrar mensaje de error si ocurre un fallo
    }
  };

  return (
    <Container>
      <Typography variant="h4">Seleccionar Menú del Día</Typography>
      {platos.length === 0 ? (
        <Typography>No hay platos disponibles para seleccionar.</Typography>
      ) : (
        platos.map((plato) => (
          <FormControlLabel
            key={plato.id}
            control={
              <Checkbox
                checked={seleccionados.includes(plato.id)}  // Mostrar como seleccionado si está en la lista de seleccionados
                onChange={() => handleSeleccion(plato.id)}  // Alternar selección al hacer click
              />
            }
            label={plato.nombre}  // Nombre del plato
          />
        ))
      )}
      {error && <Typography color="error">{error}</Typography>}
      <Button onClick={handleConfirmarMenu} variant="contained" color="primary" style={{ marginTop: '20px' }}>
        Confirmar Menú
      </Button>
    </Container>
  );
};

export default MenuDiario;
