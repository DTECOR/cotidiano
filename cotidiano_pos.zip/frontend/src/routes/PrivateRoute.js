import React from "react";
import { Navigate, Outlet } from "react-router-dom";

// 🔹 Función para obtener de forma segura los datos del usuario
const getUserData = () => {
    try {
        const token = localStorage.getItem("access_token") || sessionStorage.getItem("access_token");
        const role = localStorage.getItem("user_role") || sessionStorage.getItem("user_role");
        return { token, role };
    } catch (error) {
        console.error("🔴 Error accediendo al almacenamiento:", error);
        return { token: null, role: null };
    }
};

/**
 * 🔐 Componente PrivateRoute
 * Protege las rutas restringidas según el rol del usuario y su autenticación.
 * @param {Array} allowedRoles - Lista de roles permitidos para acceder a la ruta
 * @returns {JSX.Element}
 */
const PrivateRoute = ({ allowedRoles }) => {
    const { token, role } = getUserData();

    // 🔹 Si no hay token, redirige al login
    if (!token) {
        console.warn("🔴 Usuario no autenticado. Redirigiendo a login...");
        return <Navigate to="/login" replace />;
    }

    // 🔹 Si el usuario no tiene un rol válido, también lo redirige a login
    if (!role) {
        console.warn("🔴 No se encontró el rol del usuario. Redirigiendo a login...");
        return <Navigate to="/login" replace />;
    }

    // 🔹 Si el rol del usuario no está en la lista de roles permitidos, lo manda al Dashboard
    if (!allowedRoles.includes(role)) {
        console.warn(`🔴 Acceso denegado para el rol: ${role}. Redirigiendo a Dashboard...`);
        return <Navigate to="/dashboard" replace />;
    }

    return <Outlet />; // ✅ Renderiza la ruta protegida si el usuario tiene permisos
};

export default PrivateRoute;
