import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import PrivateRoute from "./routes/PrivateRoute";
import Sidebar from "./components/Sidebar";
import LoginForm from "./pages/LoginForm"; 
import Dashboard from "./pages/Dashboard";
import Ordenes from "./components/Ordenes";
import AdminUsuarios from "./pages/AdminUsuarios";
import MenuCocinero from "./pages/MenuCocinero";
import Facturacion from "./pages/Facturacion";
import Inventario from "./pages/Inventario";

const App = () => {
  return (
    <Router>
      <Sidebar /> {/* ✅ Sidebar está dentro del Router para que las rutas funcionen bien */}

      <Routes>
        {/* Ruta pública para el login */}
        <Route path="/login" element={<LoginForm />} />

        {/* Rutas protegidas según el rol */}
        <Route element={<PrivateRoute allowedRoles={["ADMIN", "COCINERO", "MESERO", "CAJERO"]} />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/ordenes" element={<Ordenes />} />
        </Route>

        <Route element={<PrivateRoute allowedRoles={["ADMIN"]} />}>
          <Route path="/usuarios" element={<AdminUsuarios />} />
          <Route path="/inventario" element={<Inventario />} />
        </Route>

        <Route element={<PrivateRoute allowedRoles={["COCINERO"]} />}>
          <Route path="/menu" element={<MenuCocinero />} />
        </Route>

        <Route element={<PrivateRoute allowedRoles={["CAJERO"]} />}>
          <Route path="/facturacion" element={<Facturacion />} />
        </Route>

        {/* Redirección global */}
        <Route path="*" element={<Navigate to="/dashboard" />} />
      </Routes>
    </Router>
  );
};

export default App;
