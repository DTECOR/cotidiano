from rest_framework.urlpatterns import format_suffix_patterns
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ProductoViewSet, IngredienteViewSet, ProductoIngredienteViewSet

# 🔹 Router para las vistas basadas en ViewSets
router = DefaultRouter()
router.register(r'productos', ProductoViewSet, basename='producto')
router.register(r'ingredientes', IngredienteViewSet, basename='ingrediente')
router.register(r'producto-ingredientes', ProductoIngredienteViewSet, basename='producto-ingrediente')

urlpatterns = [
    path('', include(router.urls)),  # 🔹 Agregar rutas de la API
]

urlpatterns = format_suffix_patterns(urlpatterns)
