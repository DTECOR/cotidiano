from django.db import models
from django.core.exceptions import ValidationError

# 🔹 Modelo Ingrediente
class Ingrediente(models.Model):
    UNIDADES = [
        ('g', 'Gramos'),
        ('kg', 'Kilogramos'),
        ('ml', 'Mililitros'),
        ('l', 'Litros'),
        ('unidad', 'Unidad'),
    ]

    nombre = models.CharField(max_length=100, verbose_name="Nombre del Ingrediente")
    stock = models.FloatField(verbose_name="Stock Disponible")
    unidad_medida = models.CharField(max_length=10, choices=UNIDADES, default='unidad', verbose_name="Unidad de Medida")

    def clean(self):
        if self.stock < 0:
            raise ValidationError("El stock del ingrediente no puede ser negativo.")

    def __str__(self):
        return f"{self.nombre} ({self.unidad_medida})"

    class Meta:
        verbose_name = "Ingrediente"
        verbose_name_plural = "Ingredientes"

    def reducir_stock(self, cantidad):
        """Reduce el stock y genera alertas si el ingrediente está bajo."""
        if self.stock < cantidad:
            raise ValidationError(f"Stock insuficiente para {self.nombre}.")

        self.stock -= cantidad
        self.save()

        if self.stock <= 0:
            return f"⚠️ ¡Atención! El ingrediente {self.nombre} se ha agotado."
        elif self.stock < 10:
            return f"⚠️ El ingrediente {self.nombre} está bajo en stock. ({self.stock} {self.unidad_medida} restantes)"
        return None

    def verificar_stock_minimo(self):
        """Retorna una advertencia si el stock está bajo."""
        if self.stock < 10:  # Se puede ajustar según el umbral crítico
            return f"⚠️ El ingrediente {self.nombre} está bajo en stock. ({self.stock} {self.unidad_medida} restantes)"
        return None

# 🔹 Modelo Producto
class Producto(models.Model):
    nombre = models.CharField(max_length=100, verbose_name="Nombre del Producto")
    descripcion = models.TextField(blank=True, null=True, verbose_name="Descripción")
    precio = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Precio")
    stock = models.PositiveIntegerField(verbose_name="Stock Disponible")
    imagen = models.ImageField(upload_to='productos/', blank=True, null=True, verbose_name="Imagen del Producto")

    def clean(self):
        if self.stock < 0:
            raise ValidationError("El stock no puede ser negativo.")

    def __str__(self):
        return self.nombre

    class Meta:
        verbose_name = "Producto"
        verbose_name_plural = "Productos"

# 🔹 Modelo ProductoIngrediente (relación Producto - Ingrediente)
class ProductoIngrediente(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name="ingredientes")
    ingrediente = models.ForeignKey(Ingrediente, on_delete=models.CASCADE, related_name="productos")
    cantidad_necesaria = models.FloatField(verbose_name="Cantidad Necesaria")

    def __str__(self):
        return f"{self.cantidad_necesaria} {self.ingrediente.unidad_medida} de {self.ingrediente.nombre} para {self.producto.nombre}"

    class Meta:
        verbose_name = "Relación Producto-Ingrediente"
        verbose_name_plural = "Relaciones Producto-Ingrediente"
