from rest_framework import serializers
from .models import Producto, Ingrediente, ProductoIngrediente

# 🔹 Serializer para Ingredientes
class IngredienteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ingrediente
        fields = ['id', 'nombre', 'stock', 'unidad_medida']

    def validate_stock(self, value):
        if value < 0:
            raise serializers.ValidationError("El stock del ingrediente no puede ser negativo.")
        return value

# 🔹 Serializer para ProductoIngrediente (relación Producto - Ingrediente)
class ProductoIngredienteSerializer(serializers.ModelSerializer):
    ingrediente = serializers.PrimaryKeyRelatedField(queryset=Ingrediente.objects.all())

    class Meta:
        model = ProductoIngrediente
        fields = ['id', 'producto', 'ingrediente', 'cantidad_necesaria']

# 🔹 Serializer para Producto
class ProductoSerializer(serializers.ModelSerializer):
    ingredientes = ProductoIngredienteSerializer(many=True, read_only=True, source='ingredientes')

    class Meta:
        model = Producto
        fields = ['id', 'nombre', 'descripcion', 'precio', 'stock', 'imagen', 'ingredientes']

    def validate_stock(self, value):
        if value < 0:
            raise serializers.ValidationError("El stock del producto no puede ser negativo.")
        return value
