from rest_framework import viewsets, permissions, status
from .models import Producto, Ingrediente, ProductoIngrediente
from .serializers import ProductoSerializer, IngredienteSerializer, ProductoIngredienteSerializer
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

# 🔹 ViewSet para Productos
class ProductoViewSet(viewsets.ModelViewSet):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer
    permission_classes = [IsAuthenticated]  # ✅ Asegurar que solo usuarios autenticados accedan

# 🔹 ViewSet para Ingredientes
class IngredienteViewSet(viewsets.ModelViewSet):
    queryset = Ingrediente.objects.all()
    serializer_class = IngredienteSerializer
    permission_classes = [IsAuthenticated]

def update(self, request, *args, **kwargs):
    instance = self.get_object()
    nuevo_stock = request.data.get("stock", instance.stock)

    try:
        nuevo_stock = float(nuevo_stock)
        if nuevo_stock < 0:
            return Response({"error": "El stock no puede ser negativo."}, status=status.HTTP_400_BAD_REQUEST)
    except ValueError:
        return Response({"error": "El stock debe ser un número válido."}, status=status.HTTP_400_BAD_REQUEST)

    instance.stock = nuevo_stock
    instance.save()
    return Response({"message": "Stock actualizado correctamente"})

# 🔹 ViewSet para ProductoIngrediente
class ProductoIngredienteViewSet(viewsets.ModelViewSet):
    queryset = ProductoIngrediente.objects.all()
    serializer_class = ProductoIngredienteSerializer
    permission_classes = [IsAuthenticated]
