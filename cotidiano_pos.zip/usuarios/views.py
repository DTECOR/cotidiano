from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework import status
from django.contrib.auth import get_user_model

Usuario = get_user_model()

class LogoutView(APIView):
    """
    Cierra sesión invalidando el token de refresco.
    """
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            refresh_token = request.data.get("refresh")
            if not refresh_token:
                return Response({"error": "Token de refresco requerido."}, status=status.HTTP_400_BAD_REQUEST)

            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response({"detail": "Logout exitoso, token invalidado."}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": f"Error al cerrar sesión: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)


class ObtenerUsuarioActualView(APIView):
    """
    Retorna los datos del usuario autenticado.
    """
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        usuario = request.user
        return Response({
            "id": usuario.id,
            "nombre": usuario.nombre,
            "email": usuario.email,
            "rol": usuario.rol,
            "activo": usuario.is_active,
        }, status=status.HTTP_200_OK)

