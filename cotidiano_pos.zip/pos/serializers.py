from rest_framework import serializers
from django.contrib.auth import authenticate
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from .models import Usuario, Producto, Orden, DetalleOrden, Ingrediente, ProductoIngrediente, MenuDiario

class UsuarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Usuario
        fields = ['id', 'email', 'username', 'rol', 'is_active', 'password']
        extra_kwargs = {
            'password': {'write_only': True},  
        }

    def create(self, validated_data):
        validated_data["username"] = validated_data["email"]  
        user = Usuario.objects.create_user(**validated_data)
        return user

    def update(self, instance, validated_data):
        instance.username = validated_data.get('username', instance.username)
        instance.email = validated_data.get('email', instance.email)
        instance.rol = validated_data.get('rol', instance.rol)
        if 'password' in validated_data:
            instance.set_password(validated_data['password'])
        instance.save()
        return instance
    
    def validate_email(self, value):
        if self.instance:  # Si se está actualizando, no debe validar duplicados
            return value
        if Usuario.objects.filter(email=value).exists():
            raise serializers.ValidationError("El email ya está en uso.")
        return value


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token['email'] = user.email  
        return token

    def validate(self, attrs):
        email = attrs.get("email")
        password = attrs.get("password")

        user = authenticate(username=email, password=password)
        if user is None:
            raise serializers.ValidationError("Correo o contraseña incorrectos.")
        if not email or not password:
            raise serializers.ValidationError({"error": "Se requiere email y contraseña"})

        data = super().validate(attrs)
        data["email"] = user.email
        return data


class ProductoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Producto
        fields = ['id', 'nombre', 'descripcion', 'precio', 'stock', 'imagen']

    def validate_stock(self, value):
        if value < 0:
            raise serializers.ValidationError("El stock no puede ser negativo.")
        return value


class IngredienteSerializer(serializers.ModelSerializer):
    usuario_registro = serializers.CharField(source="usuario.username", read_only=True)
    cantidad_usada = serializers.SerializerMethodField()

    class Meta:
        model = Ingrediente
        fields = ['id', 'nombre', 'stock', 'unidad_medida', 'stock_minimo',"precio", "fecha_compra", "usuario_registro", "cantidad_usada"]

    def validate_stock(self, value):
        if value < 0:
            raise serializers.ValidationError("El stock del ingrediente no puede ser negativo.")
        return value

    def get_cantidad_usada(self, obj):
        return obj.detalleorden_set.aggregate(total_usado=Sum("cantidad"))["total_usado"] or 0

class ProductoIngredienteSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductoIngrediente
        fields = '__all__'


class DetalleOrdenSerializer(serializers.ModelSerializer):
    class Meta:
        model = DetalleOrden
        fields = '__all__'


class OrdenSerializer(serializers.ModelSerializer):
    detalles = DetalleOrdenSerializer(many=True, required=True)

    class Meta:
        model = Orden
        fields = '__all__'

    def create(self, validated_data):
        detalles_data = validated_data.pop('detalles', [])
        orden = Orden.objects.create(**validated_data)

        for detalle in detalles_data:
            DetalleOrden.objects.create(orden=orden, **detalle)

        return orden


# 🔹 Serializer para MenuDiario
class MenuDiarioSerializer(serializers.ModelSerializer):
    platos = ProductoSerializer(many=True)

    class Meta:
        model = MenuDiario
        fields = ['fecha', 'platos']

    def create(self, validated_data):
        platos_data = validated_data.pop('platos', [])
        menu_diario = MenuDiario.objects.create(**validated_data)

        for plato_data in platos_data:
            menu_diario.platos.add(plato_data)

        return menu_diario

    def validate(self, data):
        """Valida si los ingredientes necesarios para los platos están disponibles."""
        platos = data.get('platos', [])
        for plato in platos:
            for ingrediente_rel in ProductoIngrediente.objects.filter(producto=plato):
                ingrediente = ingrediente_rel.ingrediente
                if ingrediente.stock < ingrediente_rel.cantidad_necesaria:
                    raise serializers.ValidationError(
                        f"No hay suficiente {ingrediente.nombre} para preparar {plato.nombre}."
                    )
        return data
