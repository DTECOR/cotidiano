from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    UsuarioViewSet, ProductoViewSet, OrdenViewSet, DetalleOrdenViewSet, obtener_inventario,
    IngredienteViewSet, ProductoIngredienteViewSet, LogoutView, CustomTokenObtainPairView,
    definir_menu_diario, cambiar_estado_orden, obtener_usuario_actual
)

# ✅ Se creó el router de DRF para las vistas basadas en ViewSets
router = DefaultRouter()
router.register(r'usuarios', UsuarioViewSet, basename='usuario')
router.register(r'productos', ProductoViewSet, basename='producto')
router.register(r'ordenes', OrdenViewSet, basename='orden')
router.register(r'detalles-orden', DetalleOrdenViewSet, basename='detalle-orden')
router.register(r'ingredientes', IngredienteViewSet, basename='ingrediente')
router.register(r'productos-ingredientes', ProductoIngredienteViewSet, basename='producto-ingrediente')

# ✅ Lista de URL patterns
urlpatterns = [
    # 🔹 Se incluyen las rutas generadas por el router
    path('api/', include(router.urls)),

    # 🔹 Rutas de autenticación y sesión
    path('api/token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/logout/', LogoutView.as_view(), name='logout'),
    path('api/usuario/', obtener_usuario_actual, name='obtener_usuario_actual'),

    # 🔹 Rutas para órdenes
    path('api/ordenes/estado/<int:pk>/', cambiar_estado_orden, name='cambiar_estado_orden'),

    # 🔹 Rutas para el Inventario
    path('api/inventario/', obtener_inventario, name='inventario'),

    # 🔹 Gestión del menú diario
    path('api/menu/diario/', definir_menu_diario, name='definir_menu_diario'),
]
