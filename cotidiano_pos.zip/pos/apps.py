from django.apps import AppConfig

class PosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pos'  # Asegurar que el nombre coincide con `INSTALLED_APPS`
