from django.core.exceptions import ValidationError
from django.contrib.auth.models import AbstractUser
from django.db import models
from datetime import date

# 🔹 Modelo Usuario (Extiende de AbstractUser para autenticación)
class Usuario(AbstractUser):  
    ROLES = [
        ('ADMIN', 'Administrador'),
        ('MESERO', 'Mesero'),
        ('CAJERO', 'Cajero'),
        ('COCINERO', 'Cocinero'),
    ]
    
    nombre = models.CharField(max_length=100, verbose_name="Nombre Completo")
    rol = models.CharField(max_length=20, choices=ROLES, verbose_name="Rol de Usuario")
    email = models.EmailField(unique=True, verbose_name="Correo Electrónico")
    username = models.CharField(max_length=150, unique=True, default="usuario_temporal")  
    USERNAME_FIELD = 'email'  
    REQUIRED_FIELDS = ['username', 'rol']  

    def __str__(self):
        return f"{self.nombre} ({self.rol})"

    class Meta:
        verbose_name = "Usuario"
        verbose_name_plural = "Usuarios"
        unique_together = ('email',)  # Asegura que el email sea único

# 🔹 Modelo Producto
class Producto(models.Model):
    nombre = models.CharField(max_length=100, verbose_name="Nombre del Producto")
    descripcion = models.TextField(blank=True, null=True, verbose_name="Descripción")
    precio = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Precio")
    stock = models.PositiveIntegerField(verbose_name="Stock Disponible")
    imagen = models.ImageField(upload_to='productos/', blank=True, null=True, verbose_name="Imagen del Producto")

    def clean(self):
        if self.stock < 0:
            raise ValidationError("El stock no puede ser negativo.")

    def __str__(self):
        return self.nombre

    class Meta:
        verbose_name = "Producto"
        verbose_name_plural = "Productos"

# 🔹 Modelo Orden
class Orden(models.Model):
    ESTADOS = [
        ('PENDIENTE', 'Pendiente'),
        ('EN_PREPARACION', 'En preparación'),
        ('LISTO', 'Listo para entregar'),
        ('ENTREGADO', 'Entregado'),
    ]

    mesero = models.ForeignKey(Usuario, on_delete=models.SET_NULL, null=True, verbose_name="Mesero Responsable")
    estado = models.CharField(max_length=20, choices=ESTADOS, default='PENDIENTE', verbose_name="Estado de la Orden")
    fecha_creacion = models.DateTimeField(auto_now_add=True, verbose_name="Fecha de Creación")

    def __str__(self):
        return f"Orden {self.id} - {self.estado}"

    class Meta:
        verbose_name = "Orden"
        verbose_name_plural = "Órdenes"

# 🔹 Modelo DetalleOrden
class DetalleOrden(models.Model):
    orden = models.ForeignKey(Orden, on_delete=models.CASCADE, related_name="detalles", verbose_name="Orden")
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE, verbose_name="Producto")
    cantidad = models.PositiveIntegerField(verbose_name="Cantidad")

    def __str__(self):
        return f"{self.cantidad}x {self.producto.nombre} en Orden {self.orden.id}"

    class Meta:
        verbose_name = "Detalle de Orden"
        verbose_name_plural = "Detalles de Órdenes"

# 🔹 Modelo Ingrediente
class Ingrediente(models.Model):
    nombre = models.CharField(max_length=100, verbose_name="Nombre del Ingrediente")
    stock = models.FloatField(verbose_name="Stock Disponible")
    stock_minimo = models.FloatField(default=10, verbose_name="Stock Mínimo de Seguridad")
    
    UNIDADES = [
        ('g', 'Gramos'),
        ('kg', 'Kilogramos'),
        ('ml', 'Mililitros'),
        ('l', 'Litros'),
        ('unidad', 'Unidad'),
    ]
    unidad_medida = models.CharField(max_length=10, choices=UNIDADES, default='unidad', verbose_name="Unidad de Medida")

    def clean(self):
        if self.stock < 0:
            raise ValidationError("El stock del ingrediente no puede ser negativo.")

    def __str__(self):
        return f"{self.nombre} ({self.unidad_medida})"

    class Meta:
        verbose_name = "Ingrediente"
        verbose_name_plural = "Ingredientes"

    def reducir_stock(self, cantidad):
        if self.stock < cantidad:
            raise ValidationError(f"Stock insuficiente para {self.nombre}.")
        self.stock -= cantidad
        self.save()

    def verificar_stock_minimo(self):
        if self.stock < self.stock_minimo:
            return f"⚠️ El ingrediente {self.nombre} está bajo en stock. ({self.stock} {self.unidad_medida} restantes)"
        return None

# 🔹 Modelo ProductoIngrediente
class ProductoIngrediente(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE, verbose_name="Producto")
    ingrediente = models.ForeignKey(Ingrediente, on_delete=models.CASCADE, verbose_name="Ingrediente")
    cantidad_necesaria = models.FloatField(verbose_name="Cantidad Necesaria")

    def clean(self):
        if self.cantidad_necesaria <= 0:
            raise ValidationError("La cantidad necesaria debe ser mayor a 0.")

    def __str__(self):
        return f"{self.cantidad_necesaria} {self.ingrediente.unidad_medida} de {self.ingrediente.nombre} para {self.producto.nombre}"

    class Meta:
        verbose_name = "Relación Producto-Ingrediente"
        verbose_name_plural = "Relaciones Producto-Ingrediente"

# 🔹 Modelo MenuDiario
class MenuDiario(models.Model):
    fecha = models.DateField(default=date.today, unique=True, verbose_name="Fecha del Menú")
    platos = models.ManyToManyField(Producto, verbose_name="Platos del Menú")

    class Meta:
        verbose_name = "Menú Diario"
        verbose_name_plural = "Menús Diarios"

    def clean(self):
        for plato in self.platos.all():
            for ingrediente_rel in ProductoIngrediente.objects.filter(producto=plato):
                ingrediente = ingrediente_rel.ingrediente
                if ingrediente.stock < ingrediente_rel.cantidad_necesaria:
                    raise ValidationError(f"No hay suficiente {ingrediente.nombre} para preparar {plato.nombre}.")

    def get_platos_disponibles(self):
        disponibilidad = {}
        for plato in self.platos.all():
            min_cantidad = float("inf")
            for ingrediente_rel in ProductoIngrediente.objects.filter(producto=plato):
                ingrediente = ingrediente_rel.ingrediente
                max_platos = ingrediente.stock // ingrediente_rel.cantidad_necesaria
                min_cantidad = min(min_cantidad, max_platos)
            disponibilidad[plato.nombre] = int(min_cantidad) if min_cantidad != float("inf") else 0
        return disponibilidad

    def __str__(self):
        return f"Menú del {self.fecha}"
