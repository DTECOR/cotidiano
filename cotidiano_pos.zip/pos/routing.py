from django.urls import re_path  # ✅ Asegura que importamos re_path
from .consumers import OrdenConsumer

# Rutas WebSocket
websocket_urlpatterns = [
    re_path(r"ws/ordenes/$", OrdenConsumer.as_asgi()),  # ✅ Ruta WebSocket corregida
]
