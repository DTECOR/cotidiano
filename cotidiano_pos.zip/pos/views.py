from django.shortcuts import get_object_or_404
from django.db import transaction
from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django.core.exceptions import ValidationError
from .models import MenuDiario, Usuario, Producto, Orden, DetalleOrden, Ingrediente, ProductoIngrediente
from .serializers import (
    MenuDiarioSerializer, UsuarioSerializer, ProductoSerializer, OrdenSerializer,
    DetalleOrdenSerializer, IngredienteSerializer, ProductoIngredienteSerializer
)
from .permissions import IsAdminUserOrReadOnly, IsMesero, IsCocinero, IsCajero, IsAdmin

import logging

logger = logging.getLogger(__name__)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def obtener_inventario(request):
    """Retorna la lista de ingredientes disponibles en el inventario."""
    ingredientes = Ingrediente.objects.all()
    serializer = IngredienteSerializer(ingredientes, many=True)
    return Response(serializer.data)

def obtener_usuario_actual(request):
    """Retorna los datos del usuario autenticado"""
    if not request.user.is_authenticated:
        return Response({"error": "Usuario no autenticado"}, status=status.HTTP_401_UNAUTHORIZED)

    usuario = request.user
    return Response({
        "id": usuario.id,
        "email": usuario.email,
        "rol": usuario.rol,
    })

# 🔹 Vista para gestión de usuarios
class UsuarioViewSet(viewsets.ModelViewSet):
    queryset = Usuario.objects.all()
    serializer_class = UsuarioSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAdminUserOrReadOnly]

    def get_queryset(self):
        if getattr(self.request.user, 'rol', None) != 'ADMIN':
            return Usuario.objects.filter(id=self.request.user.id)
        return super().get_queryset()

    @action(detail=True, methods=['patch'], permission_classes=[IsAuthenticated])
    def cambiar_contraseña(self, request, pk=None):
        """Permite cambiar la contraseña de un usuario"""
        usuario = get_object_or_404(Usuario, pk=pk)
        if request.user != usuario:
            return Response({'error': 'No tienes permiso para cambiar esta contraseña.'}, status=403)

        nueva_password = request.data.get("password")
        if not nueva_password:
            return Response({'error': 'Debe proporcionar una nueva contraseña.'}, status=400)

        usuario.set_password(nueva_password)
        usuario.save()
        return Response({'message': 'Contraseña actualizada exitosamente.'})

# 🔹 ViewSet para Órdenes
class OrdenViewSet(viewsets.ModelViewSet):
    queryset = Orden.objects.select_related('mesero').prefetch_related('detalles')
    serializer_class = OrdenSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        detalles = request.data.get("detalles", [])
        mesero_id = request.data.get("mesero")

        if not detalles:
            return Response({"error": "Debe incluir al menos un producto en la orden."},
                            status=status.HTTP_400_BAD_REQUEST)

        mesero = get_object_or_404(Usuario, id=mesero_id, rol="MESERO")

        with transaction.atomic():
            orden = Orden.objects.create(mesero=mesero, estado="PENDIENTE")
            detalles_objetos = [
                DetalleOrden(orden=orden, producto_id=detalle["producto"], cantidad=detalle["cantidad"])
                for detalle in detalles
            ]
            DetalleOrden.objects.bulk_create(detalles_objetos)

        return Response(OrdenSerializer(orden).data, status=status.HTTP_201_CREATED)

# 🔹 Logout Seguro con JWT
class LogoutView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        """Invalida el token de acceso mediante el refresh token"""
        refresh_token = request.data.get("refresh")
        if not refresh_token:
            return Response({"error": "Token de refresco requerido."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response({"mensaje": "Logout exitoso, token invalidado."}, status=200)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

# 🔹 Token personalizado para JWT
class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    """Serializador personalizado para el token de acceso"""
    def validate(self, attrs):
        data = super().validate(attrs)
        user = self.user

        # Agregar datos del usuario en la respuesta
        data["user"] = {
            "id": user.id,
            "email": user.email,
            "rol": user.rol  # Asegurar que se incluya el rol
        }
        return data

class CustomTokenObtainPairView(TokenObtainPairView):
    """Vista personalizada para el obtención del token"""
    serializer_class = CustomTokenObtainPairSerializer


@api_view(["POST"])

@permission_classes([IsAuthenticated])
def agregar_ingrediente(request):
    """Registrar un nuevo ingrediente en el inventario."""
    print("📥 Datos recibidos:", json.dumps(request.data, indent=4))  # ✅ Mostrar datos recibidos en consola Django

    serializer = IngredienteSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        print("✅ Ingrediente registrado correctamente:", serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    
    print("❌ Errores del serializador:", serializer.errors)  # ✅ Mostrar errores en consola Django
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

def definir_menu_diario(request):
    """Permite a los cocineros definir el menú del día"""
    if request.user.rol != "COCINERO":
        return Response({"error": "Solo los cocineros pueden definir el menú."}, status=403)

    platos_ids = request.data.get("platos", [])
    platos = Producto.objects.filter(id__in=platos_ids)

    menu_diario = MenuDiario()
    menu_diario.save()
    menu_diario.platos.set(platos)

    try:
        menu_diario.clean()
        return Response(MenuDiarioSerializer(menu_diario).data, status=201)
    except ValidationError as e:
        menu_diario.delete()
        return Response({"error": str(e)}, status=400)

@api_view(['PATCH'])
def cambiar_estado_orden(request, pk):
    """Permite cambiar el estado de una orden"""
    orden = get_object_or_404(Orden, pk=pk)

    if request.user.rol != 'ADMIN':
        return Response({"error": "Solo los administradores pueden cambiar el estado de la orden."}, status=403)

    nuevo_estado = request.data.get("estado")
    estados_validos = ['PENDIENTE', 'COMPLETADA', 'CANCELADA', 'EN_PROCESO']

    if nuevo_estado not in estados_validos:
        return Response({"error": "Estado no válido."}, status=400)

    orden.estado = nuevo_estado
    orden.save()
    return Response({"message": "Estado de la orden actualizado exitosamente."}, status=200)

class ProductoViewSet(viewsets.ModelViewSet):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer
    permission_classes = [IsAuthenticated]

class IngredienteViewSet(viewsets.ModelViewSet):
    queryset = Ingrediente.objects.all()
    serializer_class = IngredienteSerializer
    permission_classes = [IsAuthenticated]

class DetalleOrdenViewSet(viewsets.ModelViewSet):
    queryset = DetalleOrden.objects.select_related('orden', 'producto')
    serializer_class = DetalleOrdenSerializer
    permission_classes = [IsAuthenticated]

class ProductoIngredienteViewSet(viewsets.ModelViewSet):
    queryset = ProductoIngrediente.objects.select_related('producto', 'ingrediente')
    serializer_class = ProductoIngredienteSerializer
    permission_classes = [IsAuthenticated]
