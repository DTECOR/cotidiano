from rest_framework import permissions

class IsAdminUserOrReadOnly(permissions.BasePermission):
    """
    Permite acceso total solo a ADMIN. Otros usuarios solo pueden ver.
    """
    def has_permission(self, request, view):
        if view.action in ['retrieve', 'list']:  # Permite solo lectura a usuarios autenticados
            return request.user.is_authenticated
        return request.user.is_authenticated and getattr(request.user, 'rol', '') == 'ADMIN'


class IsMesero(permissions.BasePermission):
    """
    Permite acceso solo a usuarios con rol 'MESERO'.
    """
    def has_permission(self, request, view):
        return request.user.is_authenticated and getattr(request.user, 'rol', '') == 'MESERO'


class IsCocinero(permissions.BasePermission):
    """
    Permite acceso solo a usuarios con rol 'COCINERO'.
    """
    def has_permission(self, request, view):
        return request.user.is_authenticated and getattr(request.user, 'rol', '') == 'COCINERO'


class IsCajero(permissions.BasePermission):
    """
    Permite acceso solo a usuarios con rol 'CAJERO'.
    """
    def has_permission(self, request, view):
        return request.user.is_authenticated and getattr(request.user, 'rol', '') == 'CAJERO'


class IsAdmin(permissions.BasePermission):
    """
    Permite acceso solo a usuarios con rol 'ADMIN'.
    """
    def has_permission(self, request, view):
        return request.user.is_authenticated and getattr(request.user, 'rol', '') == 'ADMIN'
