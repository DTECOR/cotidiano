import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.layers import get_channel_layer

class OrdenConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        """Cuando un cliente WebSocket se conecta."""
        self.channel_layer = get_channel_layer()
        self.group_name = "ordenes"  # Nombre del grupo de WebSocket

        if self.channel_layer:
            await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        """Cuando un cliente WebSocket se desconecta."""
        if self.channel_layer:
            await self.channel_layer.group_discard(self.group_name, self.channel_name)

    async def receive(self, text_data):
        """Cuando el servidor recibe un mensaje del WebSocket."""
        try:
            data = json.loads(text_data)  # Validar JSON recibido
            mensaje = data.get("mensaje", "Mensaje vacío")

            # Enviar el mensaje al grupo "ordenes"
            if self.channel_layer:
                await self.channel_layer.group_send(
                    self.group_name,
                    {
                        "type": "orden_actualizada",
                        "mensaje": mensaje,
                    }
                )
        except json.JSONDecodeError:
            await self.send(text_data=json.dumps({"error": "Formato de mensaje inválido"}))

    async def orden_actualizada(self, event):
        """Enviar mensajes a todos los clientes conectados al WebSocket."""
        mensaje = event["mensaje"]
        await self.send(text_data=json.dumps({"mensaje": mensaje}))
