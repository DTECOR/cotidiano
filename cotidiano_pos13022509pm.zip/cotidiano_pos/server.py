import corsheaders
import django
import os
import django
from django.core.wsgi import get_wsgi_application
from django.conf import settings
from django.middleware.common import MiddlewareMixin
from django.middleware.csrf import CsrfViewMiddleware
from django.middleware.security import SecurityMiddleware
from django.middleware.clickjacking import XFrameOptionsMiddleware
from django.middleware.gzip import GZipMiddleware
from django.contrib.auth.middleware import AuthenticationMiddleware
from django.middleware.common import CommonMiddleware
from corsheaders.middleware import CorsMiddleware
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Cargar configuración de Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
django.setup()

# Iniciar la aplicación WSGI
application = get_wsgi_application()

# Middleware Global
MIDDLEWARE = [
    SecurityMiddleware,
    CommonMiddleware,
    CorsMiddleware,
    CsrfViewMiddleware,
    XFrameOptionsMiddleware,
    GZipMiddleware,  # Compresión de respuestas
    AuthenticationMiddleware,
]

# Configuración de CORS
CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",  # Permitir el acceso desde el frontend en React
    "http://127.0.0.1:8000",
    os.getenv("FRONTEND_URL", "http://localhost:3000"),
]

CORS_ALLOW_CREDENTIALS = True

# Configuración de la base de datos
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.getenv("DB_NAME"),
        "USER": os.getenv("DB_USER"),
        "PASSWORD": os.getenv("DB_PASSWORD"),
        "HOST": os.getenv("DB_HOST", "localhost"),
        "PORT": os.getenv("DB_PORT", "5432"),
    }
}

# Configuración de las rutas de la API
from django.urls import path, include

urlpatterns = [
    path("api/auth/", include("routes.authRoutes")),
    path("api/usuarios/", include("routes.userRoutes")),
    path("api/inventario/", include("routes.inventoryRoutes")),
    path("api/menu/", include("routes.menuRoutes")),
    path("api/ordenes/", include("routes.orderRoutes")),
    path("api/facturacion/", include("routes.invoiceRoutes")),
    path("api/promociones/", include("routes.promotionRoutes")),
    path("api/reportes/", include("routes.reportRoutes")),
]

if __name__ == "__main__":
    from django.core.management import execute_from_command_line
    execute_from_command_line(["manage.py", "runserver"])
