 
import React, { useState, useEffect } from "react";
import apiService from "../services/apiService";
import MenuCard from "./MenuCard";

const OrderForm = () => {
    const [platos, setPlatos] = useState([]);
    const [pedido, setPedido] = useState([]);

    useEffect(() => {
        async function fetchPlatos() {
            const data = await apiService.get("menu/listar");
            if (data) setPlatos(data);
        }
        fetchPlatos();
    }, []);

    const agregarAlPedido = (plato) => {
        setPedido((prevPedido) => {
            const existe = prevPedido.find((item) => item.id === plato.id);
            if (existe) {
                return prevPedido.map((item) =>
                    item.id === plato.id ? { ...item, cantidad: item.cantidad + 1 } : item
                );
            } else {
                return [...prevPedido, { ...plato, cantidad: 1 }];
            }
        });
    };

    const enviarPedido = async () => {
        if (pedido.length === 0) {
            alert("No hay platos en el pedido.");
            return;
        }

        const detalles = pedido.map((item) => ({
            plato: item.id,
            cantidad: item.cantidad,
        }));

        const response = await apiService.post("ordenes/registrar", { detalles });

        if (response) {
            alert("Pedido registrado correctamente.");
            setPedido([]);
        } else {
            alert("Error al registrar el pedido.");
        }
    };

    return (
        <div className="order-form">
            <h2>Registrar Pedido</h2>
            <div className="menu-grid">
                {platos.map((plato) => (
                    <MenuCard key={plato.id} plato={plato} onAddToOrder={agregarAlPedido} />
                ))}
            </div>

            <h3>Resumen del Pedido</h3>
            <ul className="pedido-lista">
                {pedido.map((item) => (
                    <li key={item.id}>
                        {item.nombre} - {item.cantidad}x
                    </li>
                ))}
            </ul>

            <button className="btn-confirm" onClick={enviarPedido}>
                Confirmar Pedido
            </button>
        </div>
    );
};

export default OrderForm;
