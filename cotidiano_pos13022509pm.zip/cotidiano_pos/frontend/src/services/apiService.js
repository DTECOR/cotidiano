 
import config from "../config/config";

const apiService = {
    async get(endpoint) {
        try {
            const response = await fetch(`${config.API_BASE_URL}/${endpoint}/`, {
                method: "GET",
                headers: config.getHeaders(),
            });

            if (!response.ok) {
                throw new Error(`Error GET: ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error("❌ Error en GET:", error);
            return null;
        }
    },

    async post(endpoint, data) {
        try {
            const response = await fetch(`${config.API_BASE_URL}/${endpoint}/`, {
                method: "POST",
                headers: config.getHeaders(),
                body: JSON.stringify(data),
            });

            if (!response.ok) {
                throw new Error(`Error POST: ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error("❌ Error en POST:", error);
            return null;
        }
    },

    async put(endpoint, data) {
        try {
            const response = await fetch(`${config.API_BASE_URL}/${endpoint}/`, {
                method: "PUT",
                headers: config.getHeaders(),
                body: JSON.stringify(data),
            });

            if (!response.ok) {
                throw new Error(`Error PUT: ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error("❌ Error en PUT:", error);
            return null;
        }
    },

    async delete(endpoint) {
        try {
            const response = await fetch(`${config.API_BASE_URL}/${endpoint}/`, {
                method: "DELETE",
                headers: config.getHeaders(),
            });

            if (!response.ok) {
                throw new Error(`Error DELETE: ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error("❌ Error en DELETE:", error);
            return null;
        }
    },
};

export default apiService;
