 
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import authService from "../services/authService";

const LoginPage = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        setError(null);

        const user = await authService.login(email, password);
        if (user) {
            // Redirección según el rol del usuario
            switch (user.role) {
                case "SuperAdmin":
                    navigate("/reportes");
                    break;
                case "Administrador":
                    navigate("/admin");
                    break;
                case "Cocinero":
                    navigate("/menu");
                    break;
                case "Mesero":
                    navigate("/ordenes");
                    break;
                case "Cajero":
                    navigate("/facturacion");
                    break;
                default:
                    navigate("/");
            }
        } else {
            setError("Correo o contraseña incorrectos.");
        }
    };

    return (
        <div className="login-page">
            <h2>Iniciar Sesión</h2>
            <form onSubmit={handleLogin}>
                <div className="form-group">
                    <label>Email:</label>
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                </div>
                <div className="form-group">
                    <label>Contraseña:</label>
                    <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                </div>
                {error && <p className="error-message">{error}</p>}
                <button type="submit">Iniciar Sesión</button>
            </form>
        </div>
    );
};

export default LoginPage;
