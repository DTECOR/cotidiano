import django

from django.db import models
from backend.inventario.models import Ingrediente  # ✅ Corrección aplicada
from backend.models.dishModel import Dish

class Recipe(models.Model):
    plato = models.ForeignKey(Dish, on_delete=models.CASCADE, related_name="recetas")
    ingrediente = models.ForeignKey(Ingrediente, on_delete=models.CASCADE, related_name="usado_en_recetas")  # ✅ Corrección aplicada
    cantidad_requerida = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        unique_together = ("plato", "ingrediente")  # Evita duplicar ingredientes en la misma receta

    def verificar_disponibilidad(self):
        """Verifica si hay suficiente stock de cada ingrediente para preparar un plato."""
        return self.ingrediente.cantidad_disponible >= self.cantidad_requerida

    def __str__(self):
        return f"{self.ingrediente.nombre} en {self.plato.nombre} - {self.cantidad_requerida} {self.ingrediente.unidad_medida}"
