import django

from django.db import models

class Dish(models.Model):
    nombre = models.CharField(max_length=255, unique=True)
    descripcion = models.TextField(blank=True, null=True)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    foto = models.ImageField(upload_to="platos/", blank=True, null=True)
    disponible = models.BooleanField(default=True)

    def verificar_disponibilidad(self):
        """Verifica si todos los ingredientes del plato tienen suficiente stock para prepararlo."""
        return all(recipe.verificar_disponibilidad() for recipe in self.recetas.all())

    def __str__(self):
        return f"{self.nombre} - ${self.precio}"
