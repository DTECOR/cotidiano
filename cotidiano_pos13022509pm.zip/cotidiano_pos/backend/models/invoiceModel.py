import django

from django.db import models
from django.contrib.auth import get_user_model
from django.apps import apps  # ✅ Corrección aplicada para evitar referencia circular

User = get_user_model()

class Invoice(models.Model):
    Order = apps.get_model("backend", "Order")  # ✅ Evita la importación circular

    METODOS_PAGO = [
        ("efectivo", "Efectivo"),
        ("tarjeta", "Tarjeta de Crédito/Débito"),
        ("transferencia", "Transferencia Bancaria"),
        ("digital", "Pago Digital (Stripe, PayPal)"),
    ]

    orden = models.OneToOneField(Order, on_delete=models.CASCADE, related_name="factura")
    fecha_hora = models.DateTimeField(auto_now_add=True)
    usuario = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="facturas_procesadas")
    subtotal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    impuestos = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    propina = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    metodo_pago = models.CharField(max_length=20, choices=METODOS_PAGO, default="efectivo")

    def __str__(self):
        return f"Factura {self.id} - Total: ${self.total}"
