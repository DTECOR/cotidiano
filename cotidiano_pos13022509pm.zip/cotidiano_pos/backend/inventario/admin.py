import django
from django.contrib import admin
from .models import Ingrediente

@admin.register(Ingrediente)
class IngredienteAdmin(admin.ModelAdmin):
    list_display = ("nombre", "cantidad_disponible", "unidad_medida", "precio_compra", "stock_bajo")
    search_fields = ("nombre",)
    list_filter = ("stock_bajo", "unidad_medida")
