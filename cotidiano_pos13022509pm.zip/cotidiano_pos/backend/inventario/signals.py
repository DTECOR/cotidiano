# backend/usuarios/signals.py
# Archivo vacío para evitar errores en `apps.py`
