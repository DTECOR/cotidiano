import rest_framework
from rest_framework import serializers
from backend.inventario.models import Ingrediente

class IngredienteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ingrediente
        fields = "__all__"
