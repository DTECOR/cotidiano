import django
from django.apps import AppConfig

class InventarioConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "backend.inventario"  # ✅ Se define correctamente el nombre de la app
