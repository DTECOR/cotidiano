from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAdminUser
from django.utils.timezone import now, timedelta
from django.db.models import Sum, Count
from backend.models.invoiceModel import Invoice
from backend.models.orderModel import Order
from backend.inventario.models import Ingrediente

@api_view(["GET"])
@permission_classes([IsAdminUser])
def reporte_ventas(request):
    """Genera un reporte de ventas con ingresos, costos y utilidad."""
    fecha_inicio = request.GET.get("fecha_inicio", now().date() - timedelta(days=7))
    fecha_fin = request.GET.get("fecha_fin", now().date())

    ventas = Invoice.objects.filter(fecha_hora__date__range=[fecha_inicio, fecha_fin]).aggregate(
        total_ingresos=Sum("total"),
        cantidad_facturas=Count("id"),
        total_costos=Sum("costo_total")
    )
    utilidad = ventas["total_ingresos"] - ventas["total_costos"]

    return Response({"ingresos": ventas["total_ingresos"], "costos": ventas["total_costos"], "utilidad": utilidad}, status=200)

@api_view(["GET"])
@permission_classes([IsAdminUser])
def reporte_inventario(request):
    """Genera un reporte de diferencias entre inventario físico y digital."""
    ingredientes = Ingrediente.objects.all()
    diferencias = [
        {"ingrediente": ing.nombre, "en_sistema": ing.cantidad, "fisico": ing.cantidad_real}
        for ing in ingredientes if ing.cantidad != ing.cantidad_real
    ]

    return Response({"diferencias": diferencias}, status=200)
