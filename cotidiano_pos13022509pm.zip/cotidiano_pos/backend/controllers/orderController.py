from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from django.db import transaction
from backend.models.orderModel import Order, OrderDetail
from backend.serializers.orderSerializers import OrderSerializer, OrderDetailSerializer
from backend.inventario.models import Ingrediente
from backend.models.invoiceModel import Invoice

@api_view(["POST"])
@permission_classes([IsAuthenticated])
@transaction.atomic
def registrar_orden(request):
    """Registra una nueva orden, verificando disponibilidad de ingredientes."""
    data = request.data
    detalles = data.get("detalles", [])

    for item in detalles:
        try:
            ingrediente = Ingrediente.objects.get(nombre=item["ingrediente"])
            if ingrediente.cantidad < item["cantidad_usada"]:
                return Response({"error": f"No hay suficiente {ingrediente.nombre} en inventario."}, status=400)
        except Ingrediente.DoesNotExist:
            return Response({"error": f"Ingrediente {item['ingrediente']} no encontrado."}, status=400)

    serializer = OrderSerializer(data=data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=201)
    return Response(serializer.errors, status=400)

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def actualizar_estado_orden(request, orden_id):
    """Actualiza el estado de una orden (Pendiente, En preparación, Listo, Pagado)."""
    try:
        orden = Order.objects.get(id=orden_id)
        estado = request.data.get("estado")
        if estado not in ["Pendiente", "En preparación", "Listo", "Pagado", "Cancelado"]:
            return Response({"error": "Estado inválido."}, status=400)
        orden.estado = estado
        orden.save()
        return Response({"message": f"Orden {orden_id} actualizada a {estado}."}, status=200)
    except Order.DoesNotExist:
        return Response({"error": "Orden no encontrada."}, status=404)
