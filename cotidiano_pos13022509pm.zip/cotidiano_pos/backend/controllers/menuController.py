import rest_framework
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from backend.models.dishModel import Dish
from backend.models.recipeModel import Recipe
from backend.models.ingredientModel import Ingredient
from inventario.serializers import IngredienteSerializer  # ✅ Corrección aplicada
from usuarios.serializers import UserSerializer  # ✅ Corrección aplicada
from backend.models.dishModel import Dish
from backend.models.recipeModel import Recipe

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def listar_platos(request):
    """Devuelve la lista de platos disponibles en el menú."""
    platos = Dish.objects.filter(disponible=True)
    return Response(DishSerializer(platos, many=True).data)

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def agregar_plato(request):
    """Permite agregar un nuevo plato al menú."""
    serializer = DishSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=201)
    return Response(serializer.errors, status=400)

@api_view(["PUT"])
@permission_classes([IsAuthenticated])
def actualizar_plato(request, id):
    """Permite actualizar la información de un plato en el menú."""
    try:
        plato = Dish.objects.get(id=id)
    except Dish.DoesNotExist:
        return Response({"error": "Plato no encontrado"}, status=404)
    
    serializer = DishSerializer(plato, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=400)

@api_view(["DELETE"])
@permission_classes([IsAuthenticated])
def eliminar_plato(request, id):
    """Permite eliminar un plato del menú."""
    try:
        plato = Dish.objects.get(id=id)
        plato.delete()
        return Response({"message": "Plato eliminado exitosamente"}, status=200)
    except Dish.DoesNotExist:
        return Response({"error": "Plato no encontrado"}, status=404)

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def verificar_disponibilidad_plato(request, id):
    """Verifica si un plato puede prepararse con los ingredientes disponibles."""
    try:
        receta = Recipe.objects.get(plato_id=id)
        ingredientes_necesarios = receta.ingredientes.all()

        for ingrediente in ingredientes_necesarios:
            if ingrediente.cantidad_disponible < receta.cantidad_requerida:
                return Response({"disponible": False, "mensaje": "Ingredientes insuficientes"}, status=400)
        
        return Response({"disponible": True, "mensaje": "Plato disponible"}, status=200)
    
    except Recipe.DoesNotExist:
        return Response({"error": "Receta no encontrada"}, status=404)
