from django.http import JsonResponse
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from backend.inventario.models import Ingrediente
from backend.serializers.ingredientSerializers import IngredientSerializer
from rest_framework.response import Response
from rest_framework import status

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def listar_ingredientes(request):
    """Lista todos los ingredientes disponibles en el inventario."""
    ingredientes = Ingrediente.objects.all()
    serializer = IngredientSerializer(ingredientes, many=True)
    return Response(serializer.data)

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def agregar_ingrediente(request):
    """Agrega un nuevo ingrediente al inventario, validando duplicados."""
    nombre = request.data.get("nombre")
    cantidad = request.data.get("cantidad")
    
    if Ingrediente.objects.filter(nombre=nombre).exists():
        return Response({"error": "Este ingrediente ya está registrado."}, status=status.HTTP_400_BAD_REQUEST)
    
    serializer = IngredientSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def descontar_ingredientes(request):
    """Descuenta ingredientes al preparar un plato."""
    ingredientes_utilizados = request.data.get("ingredientes", [])

    for ingrediente in ingredientes_utilizados:
        try:
            obj = Ingrediente.objects.get(nombre=ingrediente["nombre"])
            if obj.cantidad >= ingrediente["cantidad_usada"]:
                obj.cantidad -= ingrediente["cantidad_usada"]
                obj.save()
            else:
                return Response({"error": f"No hay suficiente {obj.nombre} en inventario."}, status=status.HTTP_400_BAD_REQUEST)
        except Ingrediente.DoesNotExist:
            return Response({"error": f"El ingrediente {ingrediente['nombre']} no existe en inventario."}, status=status.HTTP_400_BAD_REQUEST)

    return Response({"message": "Ingredientes descontados correctamente."}, status=status.HTTP_200_OK)

@api_view(["PUT"])
@permission_classes([IsAuthenticated])
def actualizar_cantidad_ingrediente(request, ingrediente_id):
    """Actualiza la cantidad de un ingrediente en el inventario."""
    try:
        ingrediente = Ingrediente.objects.get(id=ingrediente_id)
        nueva_cantidad = request.data.get("cantidad")
        if nueva_cantidad is None or not isinstance(nueva_cantidad, (int, float)):
            return Response({"error": "Cantidad inválida."}, status=status.HTTP_400_BAD_REQUEST)
        
        ingrediente.cantidad = nueva_cantidad
        ingrediente.save()
        return Response({"message": f"Cantidad de {ingrediente.nombre} actualizada correctamente."}, status=status.HTTP_200_OK)
    except Ingrediente.DoesNotExist:
        return Response({"error": "Ingrediente no encontrado."}, status=status.HTTP_404_NOT_FOUND)

@api_view(["DELETE"])
@permission_classes([IsAuthenticated])
def eliminar_ingrediente(request, ingrediente_id):
    """Elimina un ingrediente del inventario."""
    try:
        ingrediente = Ingrediente.objects.get(id=ingrediente_id)
        ingrediente.delete()
        return Response({"message": f"Ingrediente {ingrediente.nombre} eliminado correctamente."}, status=status.HTTP_200_OK)
    except Ingrediente.DoesNotExist:
        return Response({"error": "Ingrediente no encontrado."}, status=status.HTTP_404_NOT_FOUND)
