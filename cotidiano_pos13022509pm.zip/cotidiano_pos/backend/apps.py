import django
# backend/usuarios/apps.py

from django.apps import AppConfig

class UsuariosConfig(AppConfig):
    """Configuración de la aplicación Usuarios."""
    
    default_auto_field = "django.db.models.BigAutoField"
    name = "usuarios"  # ✅ Corrección aplicada

    def ready(self):
        """Carga dinámica de modelos cuando la app está lista"""
        try:
            import usuarios.signals  # 🔥 Se comenta si no es necesario
        except ModuleNotFoundError:
            pass  # Evita errores si signals.py no existe
