 
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

SMTP_HOST = os.getenv("EMAIL_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("EMAIL_PORT", 587))
EMAIL_USER = os.getenv("EMAIL_USER")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")
DEFAULT_FROM_EMAIL = os.getenv("DEFAULT_FROM_EMAIL", "no-reply@cotidiano.com")


def enviar_correo(destinatario, asunto, mensaje):
    """Envía un correo electrónico al usuario especificado."""
    try:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT)
        server.starttls()
        server.login(EMAIL_USER, EMAIL_PASSWORD)

        msg = MIMEMultipart()
        msg["From"] = DEFAULT_FROM_EMAIL
        msg["To"] = destinatario
        msg["Subject"] = asunto
        msg.attach(MIMEText(mensaje, "html"))

        server.sendmail(DEFAULT_FROM_EMAIL, destinatario, msg.as_string())
        server.quit()
        print(f"✅ Correo enviado a {destinatario}")
        return True
    except Exception as e:
        print(f"❌ Error al enviar correo a {destinatario}: {e}")
        return False


def enviar_correo_bienvenida(destinatario, nombre):
    """Envía un correo de bienvenida a un nuevo usuario."""
    asunto = "¡Bienvenido a Cotidiano!"
    mensaje = f"""
    <html>
    <body>
        <h2>¡Hola, {nombre}!</h2>
        <p>Te damos la bienvenida a Cotidiano. Ahora puedes acceder a nuestro sistema y gestionar tu cuenta.</p>
        <p>Si necesitas ayuda, contáctanos.</p>
        <br>
        <p>Saludos,</p>
        <p><strong>El equipo de Cotidiano</strong></p>
    </body>
    </html>
    """
    return enviar_correo(destinatario, asunto, mensaje)


def enviar_correo_recuperacion(destinatario, token):
    """Envía un correo de recuperación de cuenta con un enlace de restablecimiento."""
    asunto = "Recuperación de Cuenta - Cotidiano"
    mensaje = f"""
    <html>
    <body>
        <h2>Recuperación de Cuenta</h2>
        <p>Hemos recibido una solicitud para restablecer tu contraseña. Si no has hecho esta solicitud, ignora este mensaje.</p>
        <p>Para restablecer tu contraseña, haz clic en el siguiente enlace:</p>
        <a href="http://localhost:3000/reset-password/{token}">Restablecer Contraseña</a>
        <br><br>
        <p>Este enlace es válido por 30 minutos.</p>
        <br>
        <p>Saludos,</p>
        <p><strong>El equipo de Cotidiano</strong></p>
    </body>
    </html>
    """
    return enviar_correo(destinatario, asunto, mensaje)
