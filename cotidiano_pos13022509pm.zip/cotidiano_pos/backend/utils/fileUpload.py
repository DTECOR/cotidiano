import django
 
import os
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Configuración de almacenamiento
USE_AWS = os.getenv("USE_AWS", "False") == "True"
ALLOWED_FILE_TYPES = ["image/jpeg", "image/png", "image/jpg"]


def validar_tipo_archivo(archivo):
    """Verifica que el archivo sea un tipo permitido."""
    return archivo.content_type in ALLOWED_FILE_TYPES


def subir_archivo(archivo, ruta_destino="uploads/"):
    """Sube un archivo al almacenamiento local o a AWS S3."""
    if not validar_tipo_archivo(archivo):
        return None, "❌ Tipo de archivo no permitido."

    ruta_archivo = os.path.join(ruta_destino, archivo.name)

    if USE_AWS:
        from storages.backends.s3boto3 import S3Boto3Storage
        storage = S3Boto3Storage()
        storage.save(ruta_archivo, archivo)
        return storage.url(ruta_archivo), "✅ Archivo subido correctamente a S3."

    else:
        ruta_guardado = default_storage.save(ruta_archivo, ContentFile(archivo.read()))
        return default_storage.url(ruta_guardado), "✅ Archivo subido correctamente."


def eliminar_archivo(ruta_archivo):
    """Elimina un archivo del almacenamiento."""
    if default_storage.exists(ruta_archivo):
        default_storage.delete(ruta_archivo)
        return "✅ Archivo eliminado correctamente."
    return "❌ El archivo no existe."
