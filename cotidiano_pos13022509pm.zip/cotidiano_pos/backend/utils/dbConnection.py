import psycopg2
import django
 
import os
import psycopg2
from dotenv import load_dotenv
from django.db import connection

# Cargar variables de entorno
load_dotenv()

def conectar_db():
    """Establece conexión con la base de datos PostgreSQL."""
    try:
        conn = psycopg2.connect(
            dbname=os.getenv("DB_NAME"),
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASSWORD"),
            host=os.getenv("DB_HOST", "localhost"),
            port=os.getenv("DB_PORT", "5432"),
        )
        print("✅ Conexión a la base de datos establecida correctamente.")
        return conn
    except Exception as e:
        print(f"❌ Error al conectar con la base de datos: {e}")
        return None


def prueba_conexion():
    """Verifica si la base de datos está accesible desde Django ORM."""
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1;")
        print("✅ Conexión a la base de datos verificada desde Django.")
    except Exception as e:
        print(f"❌ Error en la conexión de Django con la base de datos: {e}")
