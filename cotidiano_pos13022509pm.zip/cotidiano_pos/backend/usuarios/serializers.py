import rest_framework
# backend/usuarios/serializers.py

from rest_framework import serializers
from .models import CustomUser

class UserSerializer(serializers.ModelSerializer):
    """Serializador para el modelo de usuario personalizado."""

    class Meta:
        model = CustomUser
        fields = ["id", "email", "is_staff", "is_active"]
