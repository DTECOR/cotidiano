import rest_framework
# backend/serializers/dishSerializers.py

from rest_framework import serializers
from backend.models.dishModel import Dish

class DishSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dish
        fields = "__all__"
