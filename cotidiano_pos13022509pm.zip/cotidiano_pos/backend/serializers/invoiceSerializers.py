import rest_framework
# backend/serializers/invoiceSerializers.py

from rest_framework import serializers
from backend.models.invoiceModel import Invoice

class InvoiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Invoice
        fields = "__all__"
