import rest_framework
# backend/serializers/promotionSerializers.py

from rest_framework import serializers
from backend.models.promotionModel import Promotion

class PromotionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Promotion
        fields = "__all__"
