import rest_framework
# backend/serializers/recipeSerializers.py

from rest_framework import serializers
from backend.models.recipeModel import Recipe

class RecipeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Recipe
        fields = "__all__"
