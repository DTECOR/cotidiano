import django
from django.urls import path
from backend.controllers.orderController import *  # ✅ Corrección aplicada

urlpatterns = [
    path("listar/", listar_ordenes, name="listar_ordenes"),
    path("registrar/", registrar_orden, name="registrar_orden"),
    path("actualizar/<int:id>/", actualizar_estado_orden, name="actualizar_estado_orden"),
    path("eliminar/<int:id>/", eliminar_orden, name="eliminar_orden"),
]
