import django
 
from django.urls import path
from userController import listar_usuarios, obtener_usuario, crear_usuario, actualizar_usuario, eliminar_usuario
from models.userModel import User
urlpatterns = [
    path("listar/", listar_usuarios, name="listar_usuarios"),
    path("obtener/<int:id>/", obtener_usuario, name="obtener_usuario"),
    path("crear/", crear_usuario, name="crear_usuario"),
    path("actualizar/<int:id>/", actualizar_usuario, name="actualizar_usuario"),
    path("eliminar/<int:id>/", eliminar_usuario, name="eliminar_usuario"),
]
