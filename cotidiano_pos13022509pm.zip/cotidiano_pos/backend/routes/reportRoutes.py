import django
 
from django.urls import path
from reportController import reporte_ventas, reporte_ingresos_vs_egresos, reporte_ordenes, reporte_inventario

urlpatterns = [
    path("ventas/", reporte_ventas, name="reporte_ventas"),
    path("ingresos-egresos/", reporte_ingresos_vs_egresos, name="reporte_ingresos_vs_egresos"),
    path("ordenes/", reporte_ordenes, name="reporte_ordenes"),
    path("inventario/", reporte_inventario, name="reporte_inventario"),
]
