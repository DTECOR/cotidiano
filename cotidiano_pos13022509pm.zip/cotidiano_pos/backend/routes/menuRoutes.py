import django
from django.urls import path
from backend.controllers.menuController import *  # ✅ Corrección aplicada

urlpatterns = [
    path("listar/", listar_platos, name="listar_platos"),
    path("agregar/", agregar_plato, name="agregar_plato"),
    path("actualizar/<int:id>/", actualizar_plato, name="actualizar_plato"),
    path("eliminar/<int:id>/", eliminar_plato, name="eliminar_plato"),
    path("verificar-disponibilidad/<int:id>/", verificar_disponibilidad_plato, name="verificar_disponibilidad_plato"),
]
