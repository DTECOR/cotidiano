import django
from django.urls import path
from backend.controllers.authController import *  # ✅ Corrección aplicada

urlpatterns = [
    path("register/", register, name="register"),
    path("login/", user_login, name="user_login"),
    path("logout/", user_logout, name="user_logout"),
    path("me/", get_user_data, name="get_user_data"),
    path("update/", update_user, name="update_user"),
    path("delete/", delete_user, name="delete_user"),
]
