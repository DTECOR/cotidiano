import django
from django.urls import path
from rest_framework.routers import DefaultRouter
from backend.controllers.inventoryController import (
    listar_ingredientes, agregar_ingrediente, actualizar_cantidad_ingrediente, eliminar_ingrediente
)
from backend.inventario.views import IngredienteViewSet  # ✅ Corrección aplicada

router = DefaultRouter()
router.register(r'ingredientes', IngredienteViewSet)

urlpatterns = [
    path("listar/", listar_ingredientes, name="listar_ingredientes"),
    path("agregar/", agregar_ingrediente, name="agregar_ingrediente"),
    path("actualizar/<int:ingrediente_id>/", actualizar_cantidad_ingrediente, name="actualizar_cantidad_ingrediente"),
    path("eliminar/<int:ingrediente_id>/", eliminar_ingrediente, name="eliminar_ingrediente"),
]

urlpatterns += router.urls
