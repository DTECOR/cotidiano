import rest_framework
 
from rest_framework.permissions import BasePermission
from rest_framework.exceptions import PermissionDenied

class RolePermission(BasePermission):
    """
    Middleware para verificar si el usuario tiene el rol adecuado para acceder a la ruta.
    """
    def __init__(self, allowed_roles=None):
        self.allowed_roles = allowed_roles or []

    def has_permission(self, request, view):
        user = request.user
        
        if not user.is_authenticated:
            raise PermissionDenied("No autenticado.")
        
        if user.role not in self.allowed_roles:
            raise PermissionDenied("No tienes permiso para acceder a esta función.")

        return True

# Definimos permisos específicos para cada tipo de usuario
class IsSuperAdmin(RolePermission):
    def __init__(self):
        super().__init__(allowed_roles=["SuperAdmin"])

class IsAdmin(RolePermission):
    def __init__(self):
        super().__init__(allowed_roles=["SuperAdmin", "Administrador"])

class IsCocinero(RolePermission):
    def __init__(self):
        super().__init__(allowed_roles=["Cocinero"])

class IsMesero(RolePermission):
    def __init__(self):
        super().__init__(allowed_roles=["Mesero"])

class IsCajero(RolePermission):
    def __init__(self):
        super().__init__(allowed_roles=["Cajero"])

class IsCliente(RolePermission):
    def __init__(self):
        super().__init__(allowed_roles=["Cliente"])
