import stripe
 
import os
import stripe
import requests
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Configuración de Stripe
STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY")
stripe.api_key = STRIPE_SECRET_KEY

# Configuración de PayPal
PAYPAL_CLIENT_ID = os.getenv("PAYPAL_CLIENT_ID")
PAYPAL_SECRET = os.getenv("PAYPAL_SECRET")
PAYPAL_API_BASE = "https://api-m.sandbox.paypal.com"  # Cambiar a producción si es necesario


def procesar_pago_stripe(monto, moneda="usd", descripcion="Pago Cotidiano"):
    """Genera un enlace de pago en Stripe."""
    try:
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[
                {
                    "price_data": {
                        "currency": moneda,
                        "product_data": {"name": descripcion},
                        "unit_amount": int(monto * 100),
                    },
                    "quantity": 1,
                }
            ],
            mode="payment",
            success_url="http://localhost:3000/pago-exitoso",
            cancel_url="http://localhost:3000/pago-cancelado",
        )
        return checkout_session.url
    except Exception as e:
        print(f"❌ Error en pago con Stripe: {e}")
        return None


def obtener_token_paypal():
    """Obtiene un token de autenticación para PayPal."""
    try:
        response = requests.post(
            f"{PAYPAL_API_BASE}/v1/oauth2/token",
            auth=(PAYPAL_CLIENT_ID, PAYPAL_SECRET),
            data={"grant_type": "client_credentials"},
        )
        return response.json().get("access_token")
    except Exception as e:
        print(f"❌ Error obteniendo token de PayPal: {e}")
        return None


def procesar_pago_paypal(monto, moneda="USD", descripcion="Pago Cotidiano"):
    """Genera un enlace de pago en PayPal."""
    token = obtener_token_paypal()
    if not token:
        return None

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
    }
    data = {
        "intent": "CAPTURE",
        "purchase_units": [
            {
                "amount": {"currency_code": moneda, "value": str(monto)},
                "description": descripcion,
            }
        ],
        "application_context": {
            "return_url": "http://localhost:3000/pago-exitoso",
            "cancel_url": "http://localhost:3000/pago-cancelado",
        },
    }

    try:
        response = requests.post(
            f"{PAYPAL_API_BASE}/v2/checkout/orders", json=data, headers=headers
        )
        return response.json().get("links", [{}])[1].get("href")  # URL de pago
    except Exception as e:
        print(f"❌ Error en pago con PayPal: {e}")
        return None
