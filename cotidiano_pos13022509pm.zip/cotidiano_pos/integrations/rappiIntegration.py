 
import os
import requests
from dotenv import load_dotenv
from orders.models import Order, OrderDetail
from menu.models import Dish

# Cargar variables de entorno
load_dotenv()

RAPPI_API_KEY = os.getenv("RAPPI_API_KEY")
RAPPI_API_URL = "https://api.rappi.com/v1/orders"


def obtener_pedidos_rappi():
    """Obtiene la lista de pedidos pendientes desde Rappi."""
    headers = {"Authorization": f"Bearer {RAPPI_API_KEY}"}
    
    try:
        response = requests.get(RAPPI_API_URL, headers=headers)
        pedidos = response.json().get("orders", [])
        return pedidos
    except Exception as e:
        print(f"❌ Error al obtener pedidos de Rappi: {e}")
        return []


def procesar_pedido_rappi(pedido):
    """Convierte un pedido de Rappi en una orden interna del sistema."""
    try:
        orden = Order.objects.create(
            cliente=None,  # Cliente anónimo desde Rappi
            tipo_pedido="online",
            estado="pendiente",
            total=0
        )

        total_orden = 0

        for item in pedido.get("items", []):
            try:
                plato = Dish.objects.get(nombre=item["name"])
                cantidad = int(item["quantity"])
                detalle = OrderDetail.objects.create(
                    orden=orden, plato=plato, cantidad=cantidad
                )
                total_orden += detalle.subtotal()
            except Dish.DoesNotExist:
                print(f"⚠️ Plato {item['name']} no encontrado en el sistema.")

        orden.total = total_orden
        orden.save()

        return {"message": "Pedido procesado exitosamente", "orden_id": orden.id}

    except Exception as e:
        print(f"❌ Error al procesar pedido de Rappi: {e}")
        return {"error": "Error procesando el pedido"}


def actualizar_estado_pedido_rappi(order_id, estado):
    """Envía actualización del estado del pedido a Rappi."""
    headers = {"Authorization": f"Bearer {RAPPI_API_KEY}"}
    data = {"order_id": order_id, "status": estado}

    try:
        response = requests.post(f"{RAPPI_API_URL}/update", json=data, headers=headers)
        return response.json()
    except Exception as e:
        print(f"❌ Error al actualizar estado del pedido en Rappi: {e}")
        return None
