import django
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/auth/", include("backend.routes.authRoutes")),
    path("api/inventory/", include("backend.routes.inventoryRoutes")),
    path("api/menu/", include("backend.routes.menuRoutes")),  # ✅ Corrección aplicada
    path("api/orders/", include("backend.routes.orderRoutes")),
    path("api/users/", include("backend.routes.userRoutes")),
    path("api/promotions/", include("backend.routes.promotionRoutes")),
    path("api/reports/", include("backend.routes.reportRoutes")),
]
