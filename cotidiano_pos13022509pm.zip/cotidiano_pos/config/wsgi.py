import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")  # 📌 Asegurar que apunta a config.settings

application = get_wsgi_application()  # 📌 Esto es lo que Gunicorn necesita
