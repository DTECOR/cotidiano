 
from django.db import models
from django.contrib.auth import get_user_model
from .orderModel import Order

User = get_user_model()

class Invoice(models.Model):
    METODOS_PAGO = [
        ("efectivo", "Efectivo"),
        ("tarjeta", "Tarjeta de Crédito/Débito"),
        ("transferencia", "Transferencia Bancaria"),
        ("digital", "Pago Digital (Stripe, PayPal)"),
    ]

    orden = models.OneToOneField(Order, on_delete=models.CASCADE, related_name="factura")
    fecha_hora = models.DateTimeField(auto_now_add=True)
    usuario = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="facturas_procesadas")
    subtotal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    impuestos = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    propina = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    metodo_pago = models.CharField(max_length=20, choices=METODOS_PAGO, default="efectivo")

    def calcular_total(self):
        """Calcula el total de la factura con impuestos y propina."""
        self.subtotal = self.orden.total
        self.impuestos = self.subtotal * 0.19  # IVA 19% (ajustable según normativas)
        self.total = self.subtotal + self.impuestos + self.propina
        self.save()

    def __str__(self):
        return f"Factura {self.id} - Orden {self.orden.id} - Total: ${self.total}"
