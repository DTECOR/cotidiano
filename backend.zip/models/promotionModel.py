 
from django.db import models
from .dishModel import Dish

class Promotion(models.Model):
    TIPOS_DESCUENTO = [
        ("porcentaje", "Descuento en Porcentaje"),
        ("valor_fijo", "Descuento en Valor Fijo"),
    ]

    plato = models.ForeignKey(Dish, on_delete=models.CASCADE, related_name="promociones")
    tipo_descuento = models.CharField(max_length=20, choices=TIPOS_DESCUENTO, default="porcentaje")
    valor_descuento = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField()

    def esta_activa(self):
        """Verifica si la promoción está activa según la fecha actual."""
        from django.utils.timezone import now
        return self.fecha_inicio <= now().date() <= self.fecha_fin

    def aplicar_descuento(self, precio_original):
        """Aplica el descuento al precio original del plato."""
        if self.esta_activa():
            if self.tipo_descuento == "porcentaje":
                return precio_original * (1 - (self.valor_descuento / 100))
            elif self.tipo_descuento == "valor_fijo":
                return max(precio_original - self.valor_descuento, 0)
        return precio_original

    def __str__(self):
        return f"Promoción en {self.plato.nombre} - {self.tipo_descuento} de {self.valor_descuento}"
