 
from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class Ingredient(models.Model):
    UNIDADES = [
        ("unidades", "Unidades"),
        ("libras", "Libras"),
        ("kilos", "Kilos"),
        ("bolsas", "Bolsas"),
        ("paquetes", "Paquetes"),
    ]

    nombre = models.CharField(max_length=255, unique=True)
    cantidad_disponible = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    unidad_medida = models.CharField(max_length=20, choices=UNIDADES, default="unidades")
    precio_compra = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    fecha_ingreso = models.DateTimeField(auto_now_add=True)
    usuario_registro = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="ingredientes_registrados")
    cantidad_usada = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    stock_bajo = models.BooleanField(default=False)
    stock_minimo = models.DecimalField(max_digits=10, decimal_places=2, default=5)  # Se puede modificar según necesidades

    def actualizar_stock_bajo(self):
        """Verifica si el ingrediente tiene bajo stock."""
        self.stock_bajo = self.cantidad_disponible <= self.stock_minimo
        self.save()

    def descontar_cantidad(self, cantidad_usada):
        """Descuenta la cantidad utilizada y actualiza el estado del stock."""
        if cantidad_usada > self.cantidad_disponible:
            raise ValueError("No hay suficiente stock disponible.")
        self.cantidad_disponible -= cantidad_usada
        self.cantidad_usada += cantidad_usada
        self.actualizar_stock_bajo()
        self.save()

    def __str__(self):
        return f"{self.nombre} - {self.cantidad_disponible} {self.unidad_medida}"
