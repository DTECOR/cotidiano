# backend/models/__init__.py

from django.apps import apps

# Asegura que Django haya cargado las aplicaciones antes de importar modelos
apps.get_models()

from .userModel import CustomUser
