 
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.utils.timezone import now, timedelta
from django.db.models import Sum, Count
from billing.models import Invoice
from orders.models import Order
from inventory.models import Ingredient

@api_view(["GET"])
@permission_classes([IsAdminUser])
def reporte_ventas(request):
    """Genera un reporte de ventas por rango de fechas."""
    fecha_inicio = request.GET.get("fecha_inicio", now().date() - timedelta(days=7))
    fecha_fin = request.GET.get("fecha_fin", now().date())

    ventas = Invoice.objects.filter(fecha_hora__date__range=[fecha_inicio, fecha_fin]).aggregate(
        total_ingresos=Sum("total"),
        cantidad_facturas=Count("id")
    )

    return Response({"reporte": "Ventas", "datos": ventas})


@api_view(["GET"])
@permission_classes([IsAdminUser])
def reporte_ingresos_vs_egresos(request):
    """Genera un reporte de ingresos por ventas y egresos por compras de ingredientes."""
    fecha_inicio = request.GET.get("fecha_inicio", now().date() - timedelta(days=30))
    fecha_fin = request.GET.get("fecha_fin", now().date())

    ingresos = Invoice.objects.filter(fecha_hora__date__range=[fecha_inicio, fecha_fin]).aggregate(total_ingresos=Sum("total"))["total_ingresos"] or 0
    egresos = Ingredient.objects.filter(fecha_ingreso__date__range=[fecha_inicio, fecha_fin]).aggregate(total_egresos=Sum("precio_compra"))["total_egresos"] or 0

    balance = ingresos - egresos

    return Response({"reporte": "Ingresos vs Egresos", "ingresos": ingresos, "egresos": egresos, "balance": balance})


@api_view(["GET"])
@permission_classes([IsAdminUser])
def reporte_ordenes(request):
    """Genera un reporte de órdenes completadas y canceladas en un período de tiempo."""
    fecha_inicio = request.GET.get("fecha_inicio", now().date() - timedelta(days=30))
    fecha_fin = request.GET.get("fecha_fin", now().date())

    ordenes = Order.objects.filter(fecha_hora__date__range=[fecha_inicio, fecha_fin]).values("estado").annotate(
        cantidad=Count("id")
    )

    return Response({"reporte": "Órdenes por Estado", "datos": list(ordenes)})


@api_view(["GET"])
@permission_classes([IsAdminUser])
def reporte_inventario(request):
    """Genera un reporte de ingredientes en bajo stock."""
    ingredientes_bajo_stock = Ingredient.objects.filter(stock_bajo=True)
    
    return Response({
        "reporte": "Inventario Bajo Stock",
        "ingredientes": [f"{ing.nombre} ({ing.cantidad_disponible} {ing.unidad_medida})" for ing in ingredientes_bajo_stock]
    })
