 
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from django.db import transaction
from .models import Order, OrderDetail
from .serializers import OrderSerializer, OrderDetailSerializer
from inventory.models import Ingredient
from billing.models import Invoice

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def listar_ordenes(request):
    """Devuelve la lista de órdenes activas en el restaurante."""
    estado = request.GET.get("estado", None)
    
    if estado:
        ordenes = Order.objects.filter(estado=estado)
    else:
        ordenes = Order.objects.all()
    
    return Response(OrderSerializer(ordenes, many=True).data)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
@transaction.atomic
def registrar_orden(request):
    """Registra una nueva orden con sus platos y calcula el total."""
    data = request.data
    detalles = data.get("detalles", [])
    
    orden = Order.objects.create(
        cliente=request.user if request.user.is_authenticated else None,
        tipo_pedido=data.get("tipo_pedido", "local"),
        mesa=data.get("mesa", None),
        estado="pendiente"
    )

    total = 0
    ingredientes_faltantes = []

    for detalle in detalles:
        plato_id = detalle.get("plato")
        cantidad = detalle.get("cantidad", 1)
        
        # Crear el detalle de la orden
        orden_detalle = OrderDetail.objects.create(
            orden=orden,
            plato_id=plato_id,
            cantidad=cantidad
        )
        
        # Descontar ingredientes usados en la receta
        for receta in orden_detalle.plato.recetas.all():
            if receta.ingrediente.cantidad_disponible < receta.cantidad_requerida * cantidad:
                ingredientes_faltantes.append(receta.ingrediente.nombre)
            else:
                receta.ingrediente.cantidad_disponible -= receta.cantidad_requerida * cantidad
                receta.ingrediente.save()

        total += orden_detalle.subtotal()

    if ingredientes_faltantes:
        orden.delete()
        return Response({"error": "Faltan ingredientes para preparar algunos platos.", "ingredientes": ingredientes_faltantes}, status=400)
    
    orden.total = total
    orden.save()
    
    return Response({"message": "Orden registrada exitosamente.", "orden_id": orden.id}, status=201)


@api_view(["PUT"])
@permission_classes([IsAuthenticated])
def actualizar_estado_orden(request, id):
    """Permite cambiar el estado de una orden."""
    try:
        orden = Order.objects.get(id=id)
    except Order.DoesNotExist:
        return Response({"error": "Orden no encontrada."}, status=404)

    nuevo_estado = request.data.get("estado")
    estados_validos = ["pendiente", "en_preparacion", "listo", "entregado", "pagado"]

    if nuevo_estado not in estados_validos:
        return Response({"error": "Estado no válido."}, status=400)

    orden.actualizar_estado(nuevo_estado)
    
    if nuevo_estado == "pagado":
        Invoice.objects.create(orden=orden, usuario=request.user, subtotal=orden.total)
    
    return Response({"message": "Estado de la orden actualizado correctamente."})


@api_view(["DELETE"])
@permission_classes([IsAuthenticated])
def eliminar_orden(request, id):
    """Elimina una orden del sistema."""
    try:
        orden = Order.objects.get(id=id)
        orden.delete()
        return Response({"message": "Orden eliminada correctamente."})
    except Order.DoesNotExist:
        return Response({"error": "Orden no encontrada."}, status=404)
