 
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.utils.timezone import now
from .models import Promotion
from .serializers import PromotionSerializer

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def listar_promociones(request):
    """Devuelve la lista de promociones activas."""
    promociones = Promotion.objects.filter(fecha_inicio__lte=now().date(), fecha_fin__gte=now().date())
    return Response(PromotionSerializer(promociones, many=True).data)


@api_view(["POST"])
@permission_classes([IsAdminUser])
def agregar_promocion(request):
    """Permite a los administradores registrar una nueva promoción."""
    data = request.data
    promocion = Promotion.objects.create(
        plato_id=data["plato"],
        tipo_descuento=data["tipo_descuento"],
        valor_descuento=data["valor_descuento"],
        fecha_inicio=data["fecha_inicio"],
        fecha_fin=data["fecha_fin"]
    )
    return Response({"message": "Promoción agregada exitosamente."}, status=201)


@api_view(["PUT"])
@permission_classes([IsAdminUser])
def actualizar_promocion(request, id):
    """Permite actualizar los datos de una promoción existente."""
    try:
        promocion = Promotion.objects.get(id=id)
    except Promotion.DoesNotExist:
        return Response({"error": "Promoción no encontrada."}, status=404)

    promocion.tipo_descuento = request.data.get("tipo_descuento", promocion.tipo_descuento)
    promocion.valor_descuento = request.data.get("valor_descuento", promocion.valor_descuento)
    promocion.fecha_inicio = request.data.get("fecha_inicio", promocion.fecha_inicio)
    promocion.fecha_fin = request.data.get("fecha_fin", promocion.fecha_fin)
    promocion.save()

    return Response({"message": "Promoción actualizada correctamente."})


@api_view(["DELETE"])
@permission_classes([IsAdminUser])
def eliminar_promocion(request, id):
    """Permite a los administradores eliminar una promoción."""
    try:
        promocion = Promotion.objects.get(id=id)
        promocion.delete()
        return Response({"message": "Promoción eliminada correctamente."})
    except Promotion.DoesNotExist:
        return Response({"error": "Promoción no encontrada."}, status=404)
