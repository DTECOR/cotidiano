 
from django.db.models import F
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from models.ingredientModel import Ingrediente
from .serializers import IngredientSerializer

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def listar_ingredientes(request):
    """Devuelve la lista de ingredientes con filtros opcionales."""
    stock_bajo = request.GET.get("stock_bajo", None)
    if stock_bajo == "true":
        ingredientes = Ingredient.objects.filter(stock_bajo=True)
    else:
        ingredientes = Ingredient.objects.all()
    
    return Response(IngredientSerializer(ingredientes, many=True).data)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def agregar_ingrediente(request):
    """Registra un nuevo ingrediente en el inventario."""
    data = request.data
    nombre = data.get("nombre")

    if Ingredient.objects.filter(nombre=nombre).exists():
        return Response({"error": "El ingrediente ya está registrado."}, status=400)

    ingrediente = Ingredient.objects.create(
        nombre=nombre,
        cantidad_disponible=data.get("cantidad_disponible"),
        unidad_medida=data.get("unidad_medida"),
        precio_compra=data.get("precio_compra"),
        usuario_registro=request.user
    )
    
    ingrediente.actualizar_stock_bajo()
    return Response({"message": "Ingrediente agregado exitosamente."}, status=201)


@api_view(["PUT"])
@permission_classes([IsAuthenticated])
def actualizar_cantidad_ingrediente(request, id):
    """Permite actualizar la cantidad de un ingrediente (compra o uso)."""
    try:
        ingrediente = Ingredient.objects.get(id=id)
    except Ingredient.DoesNotExist:
        return Response({"error": "Ingrediente no encontrado."}, status=404)

    cantidad_nueva = request.data.get("cantidad_disponible")
    ingrediente.cantidad_disponible = cantidad_nueva
    ingrediente.actualizar_stock_bajo()
    ingrediente.save()

    return Response({"message": "Cantidad actualizada correctamente."})


@api_view(["DELETE"])
@permission_classes([IsAuthenticated])
def eliminar_ingrediente(request, id):
    """Elimina un ingrediente del inventario."""
    try:
        ingrediente = Ingredient.objects.get(id=id)
        ingrediente.delete()
        return Response({"message": "Ingrediente eliminado correctamente."})
    except Ingredient.DoesNotExist:
        return Response({"error": "Ingrediente no encontrado."}, status=404)
