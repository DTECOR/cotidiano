 
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from .models import Dish, Recipe
from .serializers import DishSerializer, RecipeSerializer
from inventory.models import Ingredient

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def listar_platos(request):
    """Devuelve la lista de platos disponibles en el menú."""
    platos = Dish.objects.filter(disponible=True)
    return Response(DishSerializer(platos, many=True).data)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def agregar_plato(request):
    """Permite agregar un nuevo plato al menú."""
    data = request.data
    nombre = data.get("nombre")

    if Dish.objects.filter(nombre=nombre).exists():
        return Response({"error": "El plato ya está registrado."}, status=400)

    plato = Dish.objects.create(
        nombre=nombre,
        descripcion=data.get("descripcion", ""),
        precio=data.get("precio"),
        foto=data.get("foto"),
        disponible=True
    )
    return Response({"message": "Plato agregado exitosamente."}, status=201)


@api_view(["PUT"])
@permission_classes([IsAuthenticated])
def actualizar_plato(request, id):
    """Permite actualizar la información de un plato."""
    try:
        plato = Dish.objects.get(id=id)
    except Dish.DoesNotExist:
        return Response({"error": "Plato no encontrado."}, status=404)

    plato.nombre = request.data.get("nombre", plato.nombre)
    plato.descripcion = request.data.get("descripcion", plato.descripcion)
    plato.precio = request.data.get("precio", plato.precio)
    plato.foto = request.data.get("foto", plato.foto)
    plato.save()

    return Response({"message": "Plato actualizado correctamente."})


@api_view(["DELETE"])
@permission_classes([IsAuthenticated])
def eliminar_plato(request, id):
    """Elimina un plato del menú."""
    try:
        plato = Dish.objects.get(id=id)
        plato.delete()
        return Response({"message": "Plato eliminado correctamente."})
    except Dish.DoesNotExist:
        return Response({"error": "Plato no encontrado."}, status=404)


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def verificar_disponibilidad_plato(request, id):
    """Verifica si un plato puede prepararse con los ingredientes actuales."""
    try:
        plato = Dish.objects.get(id=id)
    except Dish.DoesNotExist:
        return Response({"error": "Plato no encontrado."}, status=404)

    ingredientes_faltantes = []
    for receta in plato.recetas.all():
        if receta.ingrediente.cantidad_disponible < receta.cantidad_requerida:
            ingredientes_faltantes.append(receta.ingrediente.nombre)

    if ingredientes_faltantes:
        return Response({"disponible": False, "ingredientes_faltantes": ingredientes_faltantes})
    
    return Response({"disponible": True, "message": "Plato disponible para preparación."})
