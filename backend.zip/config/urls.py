from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/auth/", include("routes.authRoutes")),
    path("api/inventory/", include("routes.inventoryRoutes")),
    path("api/menu/", include("routes.menuRoutes")),
    path("api/orders/", include("routes.orderRoutes")),
    path("api/users/", include("routes.userRoutes")),
    path("api/promotions/", include("routes.promotionRoutes")),
    path("api/reports/", include("routes.reportRoutes")),
]

# Manejo de errores 404
handler404 = "config.views.custom_404"
