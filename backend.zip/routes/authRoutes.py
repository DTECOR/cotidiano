 
from django.urls import path
from controllers.authController import register, login, logout, change_password, password_reset_request

urlpatterns = [
    path("register/", register, name="register"),
    path("login/", login, name="login"),
    path("logout/", logout, name="logout"),
    path("change-password/", change_password, name="change_password"),
    path("password-reset/", password_reset_request, name="password_reset"),
]
