 
import config from "../config/config";
import apiService from "./apiService";

const authService = {
    async login(email, password) {
        try {
            const response = await apiService.post("auth/login", { email, password });

            if (response && response.access) {
                config.saveToken(response.access);
                return response.user; // Retorna los datos del usuario autenticado
            } else {
                throw new Error("Credenciales inválidas");
            }
        } catch (error) {
            console.error("❌ Error en login:", error);
            return null;
        }
    },

    logout() {
        config.removeToken();
        return true;
    },

    async getCurrentUser() {
        try {
            const token = config.getToken();
            if (!token) return null;

            const response = await apiService.get("auth/me");
            return response ? response : null;
        } catch (error) {
            console.error("❌ Error obteniendo usuario autenticado:", error);
            return null;
        }
    },

    isAuthenticated() {
        return !!config.getToken();
    }
};

export default authService;
