import React from "react";

const MenuCard = ({ plato, onAddToOrder }) => {
    return (
        <div className="menu-card">
            <img src={plato.foto || "/default-food.png"} alt={plato.nombre} className="menu-card-image" />
            <div className="menu-card-info">
                <h3>{plato.nombre}</h3>
                <p className="menu-card-price">${plato.precio.toFixed(2)}</p>
                {!plato.disponible ? (
                    <p className="menu-card-out-of-stock">No disponible</p>
                ) : (
                    <button className="menu-card-button" onClick={() => onAddToOrder(plato)}>
                        Agregar al Pedido
                    </button>
                )}
            </div>
        </div>
    );
};

export default MenuCard;

