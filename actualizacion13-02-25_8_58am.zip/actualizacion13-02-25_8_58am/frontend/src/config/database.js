import config from "./config";

const DATABASE_API_URL = `${config.API_BASE_URL}/database`;

const databaseService = {
    obtenerDatos: async (endpoint) => {
        try {
            const response = await fetch(`${DATABASE_API_URL}/${endpoint}/`, {
                method: "GET",
                headers: config.getHeaders(),
            });

            if (!response.ok) {
                throw new Error(`Error al obtener datos: ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error("❌ Error en la consulta a la base de datos:", error);
            return null;
        }
    },
};

export default databaseService;
