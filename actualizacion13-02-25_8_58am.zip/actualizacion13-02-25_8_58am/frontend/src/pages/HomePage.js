 
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import apiService from "../services/apiService";
import MenuCard from "../components/MenuCard";
import PromotionBanner from "../components/PromotionBanner";

const HomePage = () => {
    const [platos, setPlatos] = useState([]);

    useEffect(() => {
        async function fetchPlatos() {
            const data = await apiService.get("menu/listar");
            if (data) setPlatos(data.slice(0, 4)); // Solo muestra 4 platos en la vista previa
        }
        fetchPlatos();
    }, []);

    return (
        <div className="home-page">
            <header className="hero">
                <h1>Bienvenido a COTIDIANO</h1>
                <p>Descubre nuestra deliciosa selección de platos.</p>
                <Link to="/menu" className="btn-primary">Ver Menú Completo</Link>
            </header>

            <PromotionBanner />

            <section className="menu-preview">
                <h2>Nuestros Platos Destacados</h2>
                <div className="menu-grid">
                    {platos.length > 0 ? (
                        platos.map((plato) => <MenuCard key={plato.id} plato={plato} />)
                    ) : (
                        <p>Cargando menú...</p>
                    )}
                </div>
            </section>
        </div>
    );
};

export default HomePage;
