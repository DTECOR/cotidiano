 
import React, { useState, useEffect } from "react";
import apiService from "../services/apiService";
import paymentService from "../services/paymentGateway";

const CheckoutPage = () => {
    const [ordenesPendientes, setOrdenesPendientes] = useState([]);
    const [ordenSeleccionada, setOrdenSeleccionada] = useState(null);
    const [metodoPago, setMetodoPago] = useState("efectivo");
    const [procesandoPago, setProcesandoPago] = useState(false);

    useEffect(() => {
        async function fetchOrdenes() {
            const data = await apiService.get("ordenes/listar?estado=pendiente");
            if (data) setOrdenesPendientes(data);
        }
        fetchOrdenes();
    }, []);

    const manejarPago = async () => {
        if (!ordenSeleccionada) {
            alert("Selecciona una orden para continuar.");
            return;
        }

        setProcesandoPago(true);

        let urlPago = null;
        if (metodoPago === "tarjeta") {
            urlPago = await paymentService.procesarPagoStripe(ordenSeleccionada.total, "usd");
        } else if (metodoPago === "paypal") {
            urlPago = await paymentService.procesarPagoPayPal(ordenSeleccionada.total, "USD");
        }

        if (urlPago) {
            window.location.href = urlPago;
        } else {
            // Si el pago es en efectivo, marcar la orden como pagada directamente
            const response = await apiService.put(`ordenes/actualizar-estado/${ordenSeleccionada.id}`, { estado: "pagado" });
            if (response) {
                alert("Pago registrado exitosamente. La factura ha sido generada.");
                setOrdenesPendientes((prev) => prev.filter((o) => o.id !== ordenSeleccionada.id));
                setOrdenSeleccionada(null);
            } else {
                alert("Error al registrar el pago.");
            }
        }

        setProcesandoPago(false);
    };

    return (
        <div className="checkout-page">
            <h1>Checkout - Pago de Órdenes</h1>

            <section className="order-selection">
                <h2>Órdenes Pendientes</h2>
                <ul>
                    {ordenesPendientes.length > 0 ? (
                        ordenesPendientes.map((orden) => (
                            <li key={orden.id} onClick={() => setOrdenSeleccionada(orden)} className={ordenSeleccionada?.id === orden.id ? "selected" : ""}>
                                Orden #{orden.id} - Total: ${orden.total.toFixed(2)}
                            </li>
                        ))
                    ) : (
                        <p>No hay órdenes pendientes de pago.</p>
                    )}
                </ul>
            </section>

            {ordenSeleccionada && (
                <section className="payment-method">
                    <h2>Método de Pago</h2>
                    <select value={metodoPago} onChange={(e) => setMetodoPago(e.target.value)}>
                        <option value="efectivo">Efectivo</option>
                        <option value="tarjeta">Tarjeta (Stripe)</option>
                        <option value="paypal">PayPal</option>
                    </select>

                    <button onClick={manejarPago} disabled={procesandoPago}>
                        {procesandoPago ? "Procesando..." : "Confirmar Pago"}
                    </button>
                </section>
            )}
        </div>
    );
};

export default CheckoutPage;
