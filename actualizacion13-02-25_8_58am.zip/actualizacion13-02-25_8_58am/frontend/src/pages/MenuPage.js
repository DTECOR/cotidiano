import React, { useState, useEffect } from "react";
import apiService from "../services/apiService";
import MenuCard from "../components/MenuCard";

const MenuPage = () => {
    const [platos, setPlatos] = useState([]);
    const [filtro, setFiltro] = useState("todos");
    const [busqueda, setBusqueda] = useState("");

    useEffect(() => {
        async function fetchPlatos() {
            const data = await apiService.get("menu/listar");
            if (data) setPlatos(data);
        }
        fetchPlatos();
    }, []);

    const platosFiltrados = platos.filter((plato) => {
        return (
            (filtro === "todos" || plato.categoria === filtro) &&
            plato.nombre.toLowerCase().includes(busqueda.toLowerCase())
        );
    });

    return (
        <div className="menu-page">
            <h1>Menú Completo</h1>

            <div className="menu-controls">
                <select value={filtro} onChange={(e) => setFiltro(e.target.value)}>
                    <option value="todos">Todos</option>
                    <option value="entradas">Entradas</option>
                    <option value="platos_principales">Platos Principales</option>
                    <option value="postres">Postres</option>
                    <option value="bebidas">Bebidas</option>
                </select>

                <input
                    type="text"
                    placeholder="Buscar plato..."
                    value={busqueda}
                    onChange={(e) => setBusqueda(e.target.value)}
                />
            </div>

            <div className="menu-grid">
                {platosFiltrados.length > 0 ? (
                    platosFiltrados.map((plato) => <MenuCard key={plato.id} plato={plato} />)
                ) : (
                    <p>No hay platos disponibles.</p>
                )}
            </div>
        </div>
    );
};

export default MenuPage;
