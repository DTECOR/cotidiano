#!/usr/bin/env python
import os
import sys
from pathlib import Path

if __name__ == "__main__":
    # Asegurar que Django encuentre correctamente el módulo backend
    sys.path.append(str(Path(__file__).resolve().parent / "backend"))

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "backend.config.settings")  # ← Corrección aplicada
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "No se pudo importar Django. Asegúrate de que está instalado "
            "y disponible en tu entorno de Python."
        ) from exc
    execute_from_command_line(sys.argv)
