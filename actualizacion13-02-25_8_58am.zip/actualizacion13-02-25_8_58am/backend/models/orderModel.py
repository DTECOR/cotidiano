 
from django.db import models
from django.contrib.auth import get_user_model
from .dishModel import Dish

User = get_user_model()

class Order(models.Model):
    ESTADOS_ORDEN = [
        ("pendiente", "Pendiente"),
        ("en_preparacion", "En Preparación"),
        ("listo", "Listo para Entrega"),
        ("entregado", "Entregado"),
        ("pagado", "Pagado"),
    ]

    TIPOS_PEDIDO = [
        ("local", "En Restaurante"),
        ("online", "Pedido en Línea"),
    ]

    cliente = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="ordenes_cliente")
    fecha_hora = models.DateTimeField(auto_now_add=True)
    estado = models.CharField(max_length=20, choices=ESTADOS_ORDEN, default="pendiente")
    tipo_pedido = models.CharField(max_length=10, choices=TIPOS_PEDIDO, default="local")
    mesa = models.IntegerField(blank=True, null=True)  # Solo aplica si es pedido en restaurante
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def actualizar_estado(self, nuevo_estado):
        """Actualiza el estado de la orden."""
        if nuevo_estado in dict(self.ESTADOS_ORDEN):
            self.estado = nuevo_estado
            self.save()

    def calcular_total(self):
        """Calcula el total de la orden sumando los precios de los platos pedidos."""
        self.total = sum(item.subtotal() for item in self.detalles.all())
        self.save()

    def __str__(self):
        return f"Orden {self.id} - Cliente: {self.cliente} - Estado: {self.estado}"
    

class OrderDetail(models.Model):
    orden = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="detalles")
    plato = models.ForeignKey(Dish, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)

    def subtotal(self):
        """Calcula el subtotal de este plato en la orden."""
        return self.plato.precio * self.cantidad

    def __str__(self):
        return f"{self.cantidad} x {self.plato.nombre} en Orden {self.orden.id}"
