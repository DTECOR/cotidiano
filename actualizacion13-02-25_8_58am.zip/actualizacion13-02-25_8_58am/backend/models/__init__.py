# backend/models/__init__.py
try:
    from .userModel import CustomUser
    from .ingredientModel import Ingrediente
    from .recipeModel import Receta
    from .dishModel import Plato
    from .orderModel import Orden
    from .invoiceModel import Factura
    from .promotionModel import Promocion
except ImportError:
    pass  # 🔥 Evita errores en la inicialización temprana
