# backend/models/__init__.py

# No importar modelos aquí para evitar errores de carga prematura
