# backend/controllers/inventoryController.py

from django.http import JsonResponse
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from backend.models.ingredientModel import Ingredient  # 🔥 Usa el nombre correcto del modelo
import json

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def listar_ingredientes(request):
    """Lista todos los ingredientes disponibles en el inventario."""
    ingredientes = Ingredient.objects.all()
    data = [{"nombre": i.nombre, "cantidad": i.cantidad_disponible, "unidad": i.unidad_medida} for i in ingredientes]
    return Response(data, status=status.HTTP_200_OK)

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def agregar_ingrediente(request):
    """Agrega un nuevo ingrediente al inventario."""
    data = json.loads(request.body)
    if not data.get("nombre") or not data.get("cantidad") or not data.get("unidad"):
        return JsonResponse({"error": "Todos los campos son obligatorios."}, status=400)
    
    Ingrediente.objects.create(
        nombre=data["nombre"],
        cantidad=data["cantidad"],
        unidad=data["unidad"],
        precio=data.get("precio", 0)
    )
    
    return JsonResponse({"message": "Ingrediente agregado correctamente."}, status=201)

@api_view(["PUT"])
@permission_classes([IsAuthenticated])
def actualizar_cantidad_ingrediente(request, ingrediente_id):
    """Actualiza la cantidad de un ingrediente en el inventario."""
    try:
        ingrediente = Ingrediente.objects.get(id=ingrediente_id)
        data = json.loads(request.body)
        ingrediente.cantidad = data.get("cantidad", ingrediente.cantidad)
        ingrediente.save()
        return JsonResponse({"message": "Cantidad actualizada correctamente."})
    except Ingrediente.DoesNotExist:
        return JsonResponse({"error": "Ingrediente no encontrado."}, status=404)

@api_view(["DELETE"])
@permission_classes([IsAuthenticated])
def eliminar_ingrediente(request, ingrediente_id):
    """Elimina un ingrediente del inventario."""
    try:
        ingrediente = Ingrediente.objects.get(id=ingrediente_id)
        ingrediente.delete()
        return JsonResponse({"message": "Ingrediente eliminado correctamente."})
    except Ingrediente.DoesNotExist:
        return JsonResponse({"error": "Ingrediente no encontrado."}, status=404)
