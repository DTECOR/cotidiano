from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import send_mail
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.hashers import make_password
import json

# ✅ Corrección de importación: Ahora está en `usuarios.models`
from backend.usuarios.models import CustomUser  
from backend.usuarios.serializers import UserSerializer  

@api_view(["POST"])
@permission_classes([AllowAny])
def register(request):
    """Permite registrar un nuevo usuario."""
    data = request.data
    if not data.get("username") or not data.get("password") or not data.get("email"):
        return Response({"error": "Todos los campos son obligatorios."}, status=status.HTTP_400_BAD_REQUEST)

    # Encriptar la contraseña antes de guardar
    data["password"] = make_password(data["password"])
    
    serializer = UserSerializer(data=data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Usuario registrado correctamente.", "data": serializer.data}, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(["POST"])
@permission_classes([AllowAny])
def user_login(request):
    """Autentica un usuario y devuelve un token JWT."""
    username = request.data.get("username")
    password = request.data.get("password")

    if not username or not password:
        return Response({"error": "Se requiere usuario y contraseña."}, status=status.HTTP_400_BAD_REQUEST)

    user = authenticate(username=username, password=password)
    if user:
        login(request, user)
        refresh = RefreshToken.for_user(user)
        return Response({
            "message": "Login exitoso",
            "access_token": str(refresh.access_token),
            "refresh_token": str(refresh),
            "user": UserSerializer(user).data
        }, status=status.HTTP_200_OK)
    return Response({"error": "Credenciales inválidas"}, status=status.HTTP_401_UNAUTHORIZED)

@api_view(["POST"])
def user_logout(request):
    """Cierra la sesión del usuario."""
    logout(request)
    return Response({"message": "Logout exitoso"}, status=status.HTTP_200_OK)

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def get_user_data(request):
    """Devuelve los datos del usuario autenticado."""
    user = request.user
    serializer = UserSerializer(user)
    return Response(serializer.data)

@api_view(["PUT"])
@permission_classes([IsAuthenticated])
def update_user(request):
    """Permite actualizar la información del usuario autenticado."""
    user = request.user
    serializer = UserSerializer(user, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "Usuario actualizado correctamente", "data": serializer.data})
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(["DELETE"])
@permission_classes([IsAuthenticated])
def delete_user(request):
    """Permite que un usuario elimine su cuenta."""
    user = request.user
    user.delete()
    return Response({"message": "Cuenta eliminada correctamente."}, status=status.HTTP_200_OK)
