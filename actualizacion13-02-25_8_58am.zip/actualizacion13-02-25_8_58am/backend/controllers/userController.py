 
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.contrib.auth import get_user_model
from .serializers import UserSerializer

User = get_user_model()

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def listar_usuarios(request):
    """Devuelve la lista de usuarios registrados."""
    usuarios = User.objects.all()
    return Response(UserSerializer(usuarios, many=True).data)


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def obtener_usuario(request, id):
    """Devuelve los datos de un usuario específico."""
    try:
        usuario = User.objects.get(id=id)
    except User.DoesNotExist:
        return Response({"error": "Usuario no encontrado."}, status=404)

    return Response(UserSerializer(usuario).data)


@api_view(["POST"])
@permission_classes([IsAdminUser])
def crear_usuario(request):
    """Permite a los administradores registrar un nuevo usuario."""
    data = request.data
    if User.objects.filter(email=data["email"]).exists():
        return Response({"error": "El correo ya está registrado."}, status=400)

    usuario = User.objects.create_user(
        email=data["email"],
        name=data["name"],
        role=data.get("role", "Cliente"),
        password=data["password"]
    )
    return Response({"message": "Usuario creado exitosamente."}, status=201)


@api_view(["PUT"])
@permission_classes([IsAuthenticated])
def actualizar_usuario(request, id):
    """Permite actualizar los datos de un usuario existente."""
    try:
        usuario = User.objects.get(id=id)
    except User.DoesNotExist:
        return Response({"error": "Usuario no encontrado."}, status=404)

    usuario.name = request.data.get("name", usuario.name)
    usuario.role = request.data.get("role", usuario.role)
    usuario.save()

    return Response({"message": "Usuario actualizado correctamente."})


@api_view(["DELETE"])
@permission_classes([IsAdminUser])
def eliminar_usuario(request, id):
    """Permite a los administradores eliminar un usuario."""
    try:
        usuario = User.objects.get(id=id)
        usuario.delete()
        return Response({"message": "Usuario eliminado correctamente."})
    except User.DoesNotExist:
        return Response({"error": "Usuario no encontrado."}, status=404)
