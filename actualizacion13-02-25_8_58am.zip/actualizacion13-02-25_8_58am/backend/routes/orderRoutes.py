 
from django.urls import path
from orderController import listar_ordenes, registrar_orden, actualizar_estado_orden, eliminar_orden

urlpatterns = [
    path("listar/", listar_ordenes, name="listar_ordenes"),
    path("registrar/", registrar_orden, name="registrar_orden"),
    path("actualizar-estado/<int:id>/", actualizar_estado_orden, name="actualizar_estado_orden"),
    path("eliminar/<int:id>/", eliminar_orden, name="eliminar_orden"),
]
