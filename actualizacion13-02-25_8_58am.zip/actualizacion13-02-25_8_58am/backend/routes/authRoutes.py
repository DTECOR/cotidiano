# backend/routes/authRoutes.py

from django.urls import path
from backend.controllers.authController import (
    register,
    user_login,
    user_logout,
    get_user_data,
    update_user,
    delete_user,
)

urlpatterns = [
    path("register/", register, name="register"),
    path("login/", user_login, name="user_login"),
    path("logout/", user_logout, name="user_logout"),
    path("me/", get_user_data, name="get_user_data"),
    path("update/", update_user, name="update_user"),
    path("delete/", delete_user, name="delete_user"),
]
