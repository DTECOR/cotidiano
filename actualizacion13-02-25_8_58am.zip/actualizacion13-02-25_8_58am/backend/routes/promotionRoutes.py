 
from django.urls import path
from promotionController import listar_promociones, agregar_promocion, actualizar_promocion, eliminar_promocion

urlpatterns = [
    path("listar/", listar_promociones, name="listar_promociones"),
    path("agregar/", agregar_promocion, name="agregar_promocion"),
    path("actualizar/<int:id>/", actualizar_promocion, name="actualizar_promocion"),
    path("eliminar/<int:id>/", eliminar_promocion, name="eliminar_promocion"),
]
