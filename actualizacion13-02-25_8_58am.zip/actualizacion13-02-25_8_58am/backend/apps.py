from django.apps import AppConfig

class BackendConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "backend"

    def ready(self):
        try:
            import backend.usuarios.signals  # ✅ Asegura que se carguen señales
        except ImportError:
            pass  # 🔥 Evita errores en la inicialización
