 
# backend/config/__init__.py
# Archivo vacío para indicar que config es un módulo de Python.
