 
from rest_framework.authentication import get_authorization_header
from rest_framework.exceptions import AuthenticationFailed
from rest_framework.permissions import BasePermission
from rest_framework_simplejwt.tokens import AccessToken

class IsAuthenticatedCustom(BasePermission):
    """
    Middleware personalizado para verificar si el usuario está autenticado mediante JWT.
    """
    def has_permission(self, request, view):
        auth_header = get_authorization_header(request).split()
        
        if not auth_header or len(auth_header) != 2:
            raise AuthenticationFailed("Token no proporcionado o formato incorrecto.")
        
        try:
            token = auth_header[1].decode('utf-8')
            AccessToken(token)  # Intenta decodificar el token JWT
            return True
        except Exception:
            raise AuthenticationFailed("Token inválido o expirado.")
