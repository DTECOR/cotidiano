# backend/signals.py
from django.apps import apps

def load_models():
    """Cargar modelos dinámicamente para evitar errores de inicialización."""
    apps.get_models()  # Esto forzará a Django a cargar los modelos correctamente

load_models()
