 
import os
import requests
from dotenv import load_dotenv
from orders.models import Order, OrderDetail
from menu.models import Dish

# Cargar variables de entorno
load_dotenv()

UBER_EATS_API_KEY = os.getenv("UBER_EATS_API_KEY")
UBER_EATS_API_URL = "https://api.uber.com/v1/orders"


def obtener_pedidos_uber():
    """Obtiene la lista de pedidos pendientes desde Uber Eats."""
    headers = {"Authorization": f"Bearer {UBER_EATS_API_KEY}"}

    try:
        response = requests.get(UBER_EATS_API_URL, headers=headers)
        pedidos = response.json().get("orders", [])
        return pedidos
    except Exception as e:
        print(f"❌ Error al obtener pedidos de Uber Eats: {e}")
        return []


def procesar_pedido_uber(pedido):
    """Convierte un pedido de Uber Eats en una orden interna del sistema."""
    try:
        orden = Order.objects.create(
            cliente=None,  # Cliente anónimo desde Uber Eats
            tipo_pedido="online",
            estado="pendiente",
            total=0
        )

        total_orden = 0

        for item in pedido.get("items", []):
            try:
                plato = Dish.objects.get(nombre=item["name"])
                cantidad = int(item["quantity"])
                detalle = OrderDetail.objects.create(
                    orden=orden, plato=plato, cantidad=cantidad
                )
                total_orden += detalle.subtotal()
            except Dish.DoesNotExist:
                print(f"⚠️ Plato {item['name']} no encontrado en el sistema.")

        orden.total = total_orden
        orden.save()

        return {"message": "Pedido procesado exitosamente", "orden_id": orden.id}

    except Exception as e:
        print(f"❌ Error al procesar pedido de Uber Eats: {e}")
        return {"error": "Error procesando el pedido"}


def actualizar_estado_pedido_uber(order_id, estado):
    """Envía actualización del estado del pedido a Uber Eats."""
    headers = {"Authorization": f"Bearer {UBER_EATS_API_KEY}"}
    data = {"order_id": order_id, "status": estado}

    try:
        response = requests.post(f"{UBER_EATS_API_URL}/update", json=data, headers=headers)
        return response.json()
    except Exception as e:
        print(f"❌ Error al actualizar estado del pedido en Uber Eats: {e}")
        return None
