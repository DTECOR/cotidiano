 
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import apiService from "../services/apiService";

const AdminDashboard = () => {
    const [ingredientesBajoStock, setIngredientesBajoStock] = useState([]);

    useEffect(() => {
        async function fetchIngredientes() {
            const data = await apiService.get("reportes/inventario");
            if (data) setIngredientesBajoStock(data.ingredientes);
        }
        fetchIngredientes();
    }, []);

    return (
        <div className="admin-dashboard">
            <h1>Panel de Administración</h1>

            <div className="dashboard-links">
                <Link to="/usuarios" className="dashboard-link">Gestión de Usuarios</Link>
                <Link to="/inventario" className="dashboard-link">Gestión de Inventario</Link>
                <Link to="/compras" className="dashboard-link">Registro de Compras</Link>
            </div>

            <section className="inventory-alerts">
                <h2>⚠️ Ingredientes en Bajo Stock</h2>
                {ingredientesBajoStock.length > 0 ? (
                    <ul>
                        {ingredientesBajoStock.map((ing, index) => (
                            <li key={index}>{ing}</li>
                        ))}
                    </ul>
                ) : (
                    <p>Todo en orden, no hay ingredientes con bajo stock.</p>
                )}
            </section>
        </div>
    );
};

export default AdminDashboard;
