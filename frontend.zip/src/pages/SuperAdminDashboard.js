 
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import apiService from "../services/apiService";

const SuperAdminDashboard = () => {
    const [ingresos, setIngresos] = useState(0);
    const [egresos, setEgresos] = useState(0);
    const [balance, setBalance] = useState(0);
    const [ordenes, setOrdenes] = useState([]);
    const [inventarioAuditado, setInventarioAuditado] = useState([]);

    useEffect(() => {
        async function fetchReportes() {
            const ingresosEgresos = await apiService.get("reportes/ingresos-egresos");
            if (ingresosEgresos) {
                setIngresos(ingresosEgresos.ingresos);
                setEgresos(ingresosEgresos.egresos);
                setBalance(ingresosEgresos.balance);
            }

            const ordenesEstado = await apiService.get("reportes/ordenes");
            if (ordenesEstado) setOrdenes(ordenesEstado.datos);

            const auditoria = await apiService.get("reportes/inventario");
            if (auditoria) setInventarioAuditado(auditoria.ingredientes);
        }
        fetchReportes();
    }, []);

    return (
        <div className="superadmin-dashboard">
            <h1>Panel del SuperAdmin</h1>

            <div className="dashboard-links">
                <Link to="/reportes/ventas" className="dashboard-link">Reporte de Ventas</Link>
                <Link to="/reportes/auditoria" className="dashboard-link">Auditoría de Inventario</Link>
            </div>

            <section className="financial-report">
                <h2>📊 Reporte Financiero</h2>
                <p>💰 Ingresos: ${ingresos.toFixed(2)}</p>
                <p>💸 Egresos: ${egresos.toFixed(2)}</p>
                <p>🔹 Balance Neto: ${balance.toFixed(2)}</p>
            </section>

            <section className="order-report">
                <h2>📌 Resumen de Órdenes</h2>
                <ul>
                    {ordenes.length > 0 ? (
                        ordenes.map((orden, index) => (
                            <li key={index}>
                                {orden.estado}: {orden.cantidad} órdenes
                            </li>
                        ))
                    ) : (
                        <p>Cargando datos...</p>
                    )}
                </ul>
            </section>

            <section className="inventory-audit">
                <h2>🔍 Auditoría de Inventario</h2>
                <ul>
                    {inventarioAuditado.length > 0 ? (
                        inventarioAuditado.map((ing, index) => (
                            <li key={index}>{ing}</li>
                        ))
                    ) : (
                        <p>No hay discrepancias en el inventario.</p>
                    )}
                </ul>
            </section>
        </div>
    );
};

export default SuperAdminDashboard;
