const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8000/api";
const TOKEN_KEY = "cotidiano_token";

const config = {
    API_BASE_URL,
    TOKEN_KEY,

    getHeaders: () => {
        const token = localStorage.getItem(TOKEN_KEY);
        return {
            "Content-Type": "application/json",
            ...(token && { Authorization: `Bearer ${token}` }),
        };
    },

    saveToken: (token) => {
        localStorage.setItem(TOKEN_KEY, token);
    },

    removeToken: () => {
        localStorage.removeItem(TOKEN_KEY);
    },

    getToken: () => {
        return localStorage.getItem(TOKEN_KEY);
    },
};

export default config;
