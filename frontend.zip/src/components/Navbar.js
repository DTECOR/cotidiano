 
import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import authService from "../services/authService";
import config from "../config/config";

const Navbar = () => {
    const [user, setUser] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        async function fetchUser() {
            const authenticatedUser = await authService.getCurrentUser();
            setUser(authenticatedUser);
        }
        fetchUser();
    }, []);

    const handleLogout = () => {
        authService.logout();
        navigate("/login");
    };

    return (
        <nav className="navbar">
            <Link to="/" className="navbar-brand">COTIDIANO</Link>
            
            <ul className="navbar-menu">
                <li><Link to="/">Inicio</Link></li>
                {user?.role === "Administrador" && <li><Link to="/admin">Admin</Link></li>}
                {user?.role === "Cocinero" && <li><Link to="/menu">Menú</Link></li>}
                {user?.role === "Mesero" && <li><Link to="/ordenes">Órdenes</Link></li>}
                {user?.role === "Cajero" && <li><Link to="/facturacion">Facturación</Link></li>}
                {user?.role === "SuperAdmin" && <li><Link to="/reportes">Reportes</Link></li>}
            </ul>

            <div className="navbar-actions">
                {user ? (
                    <>
                        <span>Bienvenido, {user.name}</span>
                        <button className="btn-logout" onClick={handleLogout}>Cerrar Sesión</button>
                    </>
                ) : (
                    <Link to="/login" className="btn-login">Iniciar Sesión</Link>
                )}
            </div>
        </nav>
    );
};

export default Navbar;
