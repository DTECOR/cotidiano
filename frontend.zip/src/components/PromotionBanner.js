 
import React, { useState, useEffect } from "react";
import apiService from "../services/apiService";

const PromotionBanner = () => {
    const [promociones, setPromociones] = useState([]);
    const [indice, setIndice] = useState(0);

    useEffect(() => {
        async function fetchPromociones() {
            const data = await apiService.get("promociones/listar");
            if (data) setPromociones(data);
        }
        fetchPromociones();
    }, []);

    useEffect(() => {
        if (promociones.length > 0) {
            const intervalo = setInterval(() => {
                setIndice((prevIndice) => (prevIndice + 1) % promociones.length);
            }, 5000); // Cambia la promoción cada 5 segundos

            return () => clearInterval(intervalo);
        }
    }, [promociones]);

    if (promociones.length === 0) return null;

    const promoActual = promociones[indice];

    return (
        <div className="promotion-banner">
            <h3>🔥 Promoción Especial 🔥</h3>
            <p>{promoActual.plato.nombre}</p>
            <p>
                {promoActual.tipo_descuento === "porcentaje"
                    ? `Descuento del ${promoActual.valor_descuento}%`
                    : `Descuento de $${promoActual.valor_descuento}`}
            </p>
        </div>
    );
};

export default PromotionBanner;
